# Original file: das_pde.py
# Original author: Kejun Tang, github.com/MJfadeaway/DAS
# License: MIT
# Modified by Anshima Singh, June 2026
# Changes: Modified and extended for time-dependent PDEs


from __future__ import absolute_import, division, print_function, unicode_literals
import tensorflow as tf
import numpy as np
from tensorflow.keras import layers
import BR_lib.BR_model as BR_model
import BR_lib.BR_data as BR_data
import nn_model 
import pde_model_td

import os
import shutil



def gen_train_data(n_dim, n_sample, probsetup):
    """
    generate training data for the first stage
    Args:
    -----
        n_dim: dimension
        n_sample: number of samples
        probsetup: type of problems, see das_train.py file 

    Returns:
    --------
        x, x_boundary, x_ic for probsetup 18, 20, 21, 22, 23
        data points for training, including interior data points,
        boundary data points and initial condition points
    """
    
    if probsetup == 18 or probsetup == 20 or probsetup == 21:
        if n_dim != 3:
            raise ValueError('probsetup requires n_dim = 3')
        x = BR_data.gen_square_domain(n_dim, n_sample)
        x_boundary = BR_data.gen_spacetime_boundary(n_sample)
        x_ic = BR_data.gen_spacetime_ic(n_sample)
        return x, x_boundary, x_ic

    elif probsetup == 22 or probsetup == 23:
        if n_dim < 2:
            raise ValueError('probsetups 22, 23 requires n_dim > 2 '
                             '(spatial dim + time)')
        x = BR_data.gen_square_domain(n_dim, n_sample)
        x_boundary = BR_data.gen_nd_cube_boundary_spacetime(n_dim, n_sample)
        x_ic = BR_data.gen_spacetime_ic_nd(n_dim, n_sample)
        return x, x_boundary, x_ic
    
    else:
        raise ValueError('probsetup is not valid')
        
        
        
def load_valid_data(n_dim, probsetup, alpha=10.0, store_dir='./store_data'):
    """
    load validation data for performance evaluation
    Args:
    -----
        n_dim: data dimension
        probsetup: type of problems

    Returns:
    --------
        sample_valid: validation points, numpy format
        u_true: true function values at the validation set, numpy format
    """
    if probsetup == 18:
        if n_dim != 3:
            raise ValueError('probsetup 18 requires n_dim = 3')
        if alpha <= 10:
            n_spatial = 50
        elif alpha <= 100:
            n_spatial = 100
        elif alpha <= 500:
            n_spatial = 200
        else:
            n_spatial = 256
        sample_valid, sample_valid_normalized = BR_data.gen_spacetime_validation(
            n_spatial=n_spatial, n_time=5)
        u_true = pde_model_td.exact_timedep_moving_transient(
            sample_valid_normalized, alpha=alpha)
        return sample_valid_normalized, u_true

    elif probsetup == 20:
        if n_dim != 3:
            raise ValueError('probsetup 20 requires n_dim = 3')
        if alpha <= 0.05:
            n_spatial = 200
        elif alpha <= 0.1:
            n_spatial = 100
        else:
            n_spatial = 50
        sample_valid, sample_valid_normalized = BR_data.gen_spacetime_validation(
            n_spatial=n_spatial, n_time=5)
        u_true = pde_model_td.exact_rotation(
            sample_valid_normalized, alpha=alpha)
        return sample_valid_normalized, u_true

    elif probsetup == 21:
        if n_dim != 3:
            raise ValueError('probsetup 21 requires n_dim = 3')
        # alpha=0.001 is very sharp
        # front width ~2alpha, need fine grid to resolve it
        n_spatial = 200
        sample_valid, sample_valid_normalized = BR_data.gen_spacetime_validation(
            n_spatial=n_spatial, n_time=5)
        u_true = pde_model_td.exact_burgers(
            sample_valid_normalized, alpha=alpha)
        return sample_valid_normalized, u_true
    

    elif probsetup == 22:
        if n_dim < 2:
            raise ValueError('probsetup 22 requires n_dim > 2')

        n_spatial = n_dim - 1

        if n_spatial == 4:
            n_per_dim = 9     # 9^4 × 5 = 32,805 — odd, includes origin
            n_time    = 5
        elif n_spatial == 6:
            n_per_dim = 5     # 5^6 × 5 = 78,125 — odd, includes origin
            n_time    = 5
        elif n_spatial == 8:
            n_per_dim = 3     # 3^8 × 5 = 32,805 — odd, includes origin
            n_time    = 5
        elif n_spatial == 10:
            n_per_dim = 3     # 3^10 × 5 = 295,245 — odd, includes origin
            n_time    = 5
        else:
            n_per_dim = 5
            n_time    = 5

        sample_valid, sample_valid_normalized = \
            BR_data.gen_spacetime_validation_hd_transient(
                n_spatial, n_per_dim=n_per_dim, n_time=n_time)

        u_true = pde_model_td.exact_timedep_hd_transient(sample_valid_normalized)
        return sample_valid_normalized, u_true

    elif probsetup == 23:
        if n_dim < 2:
            raise ValueError('probsetup 23 requires n_dim > 2')

        n_spatial = n_dim - 1
        n_per_dim = 5
        n_time    = 5

        sample_valid, sample_valid_normalized = \
            BR_data.gen_spacetime_validation_advection_hd(
                n_spatial, n_per_dim=n_per_dim, n_time=n_time, alpha=alpha)

        u_true = pde_model_td.exact_advection_hd(
            sample_valid_normalized, alpha=alpha)
        return sample_valid_normalized, u_true

    else:
        raise ValueError('probsetup is not valid')


class DAS():
    """
    Deep adaptive sampling (DAS) for time dependent partial differential equations
    ------------------------------------------------------------------------------------
    Here is the deep adaptive sampling method to solve time-dependent partial differential equations. 
    Solving PDEs using deep nueral networks needs to compute a loss function with sample generation. 
    In general, uniform samples are generated, but it is not an optimal choice to efficiently train models. 
    However, flow-based generative models provide an opportunity for efficient sampling, and this is exactly what DAS 
    does. 
    
    Args:
    -----
        args: input parameters
    """
    def __init__(self, args):
        self.args = args
        self._set()
        self.build_nn()
        self.build_flow()
        self._restore()
 

    def _set(self):
        args = self.args
        pde_optimizer = tf.keras.optimizers.Adam(learning_rate=args.lr)
        flow_optimizer = tf.keras.optimizers.Adam(learning_rate=args.lr)
        self.pde_optimizer = pde_optimizer
        self.flow_optimizer = flow_optimizer

        # this is for creating folder for save training and validation loss history, checkpoint and summary
        if os.path.exists(args.ckpts_dir):
            shutil.rmtree(args.ckpts_dir)
        os.mkdir(args.ckpts_dir)

        if os.path.exists(args.summary_dir):
            shutil.rmtree(args.summary_dir)
        os.mkdir(args.summary_dir)

        if os.path.exists(args.data_dir):
            shutil.rmtree(args.data_dir)
        os.mkdir(args.data_dir)

        self.pdeloss_vs_iter = []
        self.residualloss_vs_iter = []
        self.entropyloss_vs_iter = []
        self.approximate_error_vs_iter = [] #mean square error
        self.rel_l2_vs_iter  = []
        self.linf_vs_iter    = []
        self.resvar_vs_iter = []
        self.bdloss_vs_iter = []
        self.icloss_vs_iter = []


    def _restore(self):
        args = self.args
        self.ckpt = tf.train.Checkpoint(step=tf.Variable(1), optimizer=self.pde_optimizer, net=self.net_u)
        self.manager = tf.train.CheckpointManager(self.ckpt, args.ckpts_dir, max_to_keep=5)


    def build_flow(self):
        args = self.args
        # build the PDF model

        # enlarge the computation domain slightly
        xlb = -args.bd - 0.01
        xhb = args.bd + 0.01

        pdf_model = BR_model.IM_rNVP_KR_CDF('pdf_model_rNVP_KR_CDF',
                                            args.n_dim,
                                            xlb, xhb,
                                            args.n_step,
                                            args.n_depth,
                                            n_width=args.n_width,
                                            shrink_rate=args.shrink_rate,
                                            flow_coupling=args.flow_coupling,
                                            n_bins=args.n_bins4cdf,
                                            rotation=args.rotation,
                                            bounded_supp=args.bounded_supp)

        self.pdf_model = pdf_model


    def build_nn(self):
        args = self.args
        # create a neural network to approximate the solution of PDEs
        net_u = nn_model.FCNN('FCNN', 1, args.netu_depth, args.n_hidden, args.activation)

        self.net_u = net_u 


    def resample(self):
        """
        resample from the trained flow model corresponding to mesh refinement in FEM
        This function will be executed when residual loss of PDE is greater than a tolerance

        For all probsetups (time-dependent):
            Returns three separate arrays: x_interior, x_boundary, x_ic
        """
        args = self.args
        n_resample = args.n_train
        projection_operator = BR_data.projection_onto_infunitball

        if args.probsetup == 18 or args.probsetup == 20 \
                or args.probsetup == 21 or args.probsetup == 22 \
                or args.probsetup == 23: 

            x_prior = self.pdf_model.draw_samples_from_prior(n_resample, args.n_dim)
            x_candidate = self.pdf_model.mapping_from_prior(x_prior).numpy()

            # project out of bounds samples onto [-1,1]^n_dim
            x_resample, x_bd_projected = projection_operator(x_candidate)

            # initialize collections
            x_bd_collected = np.zeros((0, args.n_dim), dtype=np.float32)
            x_ic_collected = np.zeros((0, args.n_dim), dtype=np.float32)

            def get_masks(x_proj):
                """
                General mask computation for any dimension.
                Time is always the last column - already normalized to [-1,1].
                IC: t_normalized = -1
                Spatial boundary: any spatial coordinate has |xi| = 1
                Interior: t=1 face with spatial coords inside domain
                """
                
                if args.probsetup == 18 or args.probsetup == 20 \
                        or args.probsetup == 21:
                    # coded for 2D spatial
                    ic_mask = (x_proj[:, 2] == -1.0)
                    sp_mask = (
                        ((np.abs(x_proj[:, 0]) == 1.0) |
                         (np.abs(x_proj[:, 1]) == 1.0)) &
                        (~ic_mask)
                    )
                else:
                    # general tolerance-based for any dimension
                    tol = 1e-6
                    ic_mask = (np.abs(x_proj[:, -1] + 1.0) < tol)
                    sp_mask_spatial = np.zeros(x_proj.shape[0], dtype=bool)
                    for j in range(args.n_dim - 1):
                        sp_mask_spatial |= (np.abs(x_proj[:, j]) > 1.0 - tol)
                    sp_mask = sp_mask_spatial & (~ic_mask)

                interior_mask = (~ic_mask) & (~sp_mask)
                return ic_mask, sp_mask, interior_mask

            if x_bd_projected.shape[0] > 0:
                ic_mask, sp_mask, interior_mask = get_masks(x_bd_projected)

                x_bd_collected = x_bd_projected[sp_mask, :]
                x_ic_collected = x_bd_projected[ic_mask, :]
                # t=1 interior points are valid interior space-time points
                # they have t_normalized=1 --> t_original=T - still inside domain
                # no denormalization needed - solution network takes normalized time
                x_resample = np.concatenate((x_resample,
                                             x_bd_projected[interior_mask, :]),
                                             axis=0)

            # keep sampling until we have enough interior points
            nv_sample = x_resample.shape[0]
            while nv_sample < n_resample:
                n_diff          = n_resample - nv_sample
                x_prior_new     = self.pdf_model.draw_samples_from_prior(n_diff, args.n_dim)
                x_candidate_new = self.pdf_model.mapping_from_prior(x_prior_new).numpy()
                x_interior_new, x_bd_projected_new = projection_operator(x_candidate_new)

                if x_bd_projected_new.shape[0] > 0:
                    ic_mask_new, sp_mask_new, interior_mask_new = get_masks(x_bd_projected_new)

                    x_bd_collected = np.concatenate((x_bd_collected,
                                                     x_bd_projected_new[sp_mask_new, :]),
                                                     axis=0)
                    x_ic_collected = np.concatenate((x_ic_collected,
                                                     x_bd_projected_new[ic_mask_new, :]),
                                                     axis=0)
                    x_resample     = np.concatenate((x_resample,
                                                     x_interior_new,
                                                     x_bd_projected_new[interior_mask_new, :]),
                                                     axis=0)
                else:
                    x_resample = np.concatenate((x_resample, x_interior_new), axis=0)

                nv_sample = x_resample.shape[0]

            # trim interior points to n_resample
            x_resample = x_resample[:n_resample, :]

            # fill remaining boundary points if not enough
            n_bd_needed = n_resample - x_bd_collected.shape[0]
            if n_bd_needed > 0:
                if args.probsetup == 18 \
                        or args.probsetup == 20 or args.probsetup == 21:
                    x_bd_fill = BR_data.gen_spacetime_boundary(n_bd_needed)
                else:
                    x_bd_fill = BR_data.gen_nd_cube_boundary_spacetime(
                        args.n_dim, n_bd_needed)
                x_bd_new = np.concatenate((x_bd_collected, x_bd_fill), axis=0)
            else:
                x_bd_new = x_bd_collected[:n_resample, :]

            # fill remaining IC points if not enough
            n_ic_needed = n_resample - x_ic_collected.shape[0]
            if n_ic_needed > 0:
                if args.probsetup == 18 \
                        or args.probsetup == 20 or args.probsetup == 21:
                    x_ic_fill = BR_data.gen_spacetime_ic(n_ic_needed)
                else:
                    x_ic_fill = BR_data.gen_spacetime_ic_nd(args.n_dim, n_ic_needed)
                x_ic_new = np.concatenate((x_ic_collected, x_ic_fill), axis=0)
            else:
                x_ic_new = x_ic_collected[:n_resample, :]

            # return three separate arrays
            return x_resample, x_bd_new, x_ic_new

        else:
            x_prior     = self.pdf_model.draw_samples_from_prior(n_resample, args.n_dim)
            x_candidate = self.pdf_model.mapping_from_prior(x_prior).numpy()

            x_resample, x_bd_projected = projection_operator(x_candidate)
            nv_sample = x_resample.shape[0]
            while nv_sample < n_resample:
                n_diff          = n_resample - nv_sample
                x_prior_new     = self.pdf_model.draw_samples_from_prior(n_diff, args.n_dim)
                x_candidate_new = self.pdf_model.mapping_from_prior(x_prior_new).numpy()
                x_candidate_new, _ = projection_operator(x_candidate_new)
                x_resample      = np.concatenate((x_resample, x_candidate_new), axis=0)
                nv_sample       = x_resample.shape[0]

            if x_bd_projected.shape[0] < x_resample.shape[0]:
                n_add       = x_resample.shape[0] - x_bd_projected.shape[0]
                _, x_bd_add = gen_train_data(args.n_dim, n_add, args.probsetup)
                x_bd_projected = np.concatenate((x_bd_projected, x_bd_add), axis=0)
            else:
                n_s            = x_resample.shape[0]
                x_bd_projected = x_bd_projected[:n_s, :]

            # return one packed array [x_interior | x_boundary]
            x_new = np.concatenate((x_resample, x_bd_projected), axis=1)
            return x_new

    
    def get_pde_loss(self, x, x_boundary, stage_idx, x_ic=None):
        args = self.args

        if args.probsetup == 18:
            residual = pde_model_td.residual_timedep_moving_transient(
                self.net_u, x, alpha=args.alpha)
            residual_boundary = pde_model_td.boundary_loss_timedep_moving_transient(
                self.net_u, x_boundary, alpha=args.alpha)
            residual_ic = pde_model_td.ic_loss_timedep_moving_transient(
                self.net_u, x_ic)

        elif args.probsetup == 20:
            residual = pde_model_td.residual_rotation(
                self.net_u, x, alpha=args.alpha)
            residual_boundary = pde_model_td.boundary_loss_rotation(
                self.net_u, x_boundary, alpha=args.alpha)
            residual_ic = pde_model_td.ic_loss_rotation(
                self.net_u, x_ic, alpha=args.alpha)

        elif args.probsetup == 21:
            residual = pde_model_td.residual_burgers(
                self.net_u, x, alpha=args.alpha)
            residual_boundary = pde_model_td.boundary_loss_burgers(
                self.net_u, x_boundary, alpha=args.alpha)
            residual_ic = pde_model_td.ic_loss_burgers(
                self.net_u, x_ic, alpha=args.alpha)

        elif args.probsetup == 22:
            residual = pde_model_td.residual_timedep_hd_transient(
                self.net_u, x)
            residual_boundary = pde_model_td.boundary_loss_timedep_hd_transient(
                self.net_u, x_boundary)
            residual_ic = pde_model_td.ic_loss_timedep_hd_transient(
                self.net_u, x_ic)
        
        elif args.probsetup == 23:
            residual = pde_model_td.residual_advection_hd(
                self.net_u, x, alpha=args.alpha)
            residual_boundary = pde_model_td.boundary_loss_advection_hd(
                self.net_u, x_boundary, alpha=args.alpha)
            residual_ic = pde_model_td.ic_loss_advection_hd(
                self.net_u, x_ic, alpha=args.alpha)

        else:
            raise ValueError('probsetup is not valid')

        # compute pde loss
        if args.probsetup == 18 or args.probsetup == 20 \
                or args.probsetup == 21 or args.probsetup == 22 \
                or args.probsetup == 23:

            if stage_idx == 1:
                pde_loss = (tf.reduce_mean(residual) +
                            args.lambda_bd * tf.reduce_mean(residual_boundary) +
                            args.lambda_ic * tf.reduce_mean(residual_ic))
            else:
                if args.replace_all == 1:
                    if args.if_IS_residual == 0:
                        pde_loss = (tf.reduce_mean(residual) +
                                    args.lambda_bd * tf.reduce_mean(residual_boundary) +
                                    args.lambda_ic * tf.reduce_mean(residual_ic))
                    else:
                        scaling = 1000.0
                        log_pdf = tf.clip_by_value(self.pdf_model(x), -23.02585, 5.0)
                        pdfx = tf.math.exp(log_pdf)
                        weight_residual = tf.math.divide(scaling*residual, scaling*pdfx)
                        pde_loss = (tf.reduce_mean(weight_residual) +
                                    args.lambda_bd * tf.reduce_mean(residual_boundary) +
                                    args.lambda_ic * tf.reduce_mean(residual_ic))
                else:
                    if args.if_IS_residual == 0:
                        pde_loss = (tf.reduce_mean(residual) +
                                    args.lambda_bd * tf.reduce_mean(residual_boundary) +
                                    args.lambda_ic * tf.reduce_mean(residual_ic))
                    else:
                        scaling = 1000.0
                        log_pdf = tf.clip_by_value(self.pdf_model(x), -23.02585, 5.0)
                        pdfx = tf.math.exp(log_pdf)
                        weight_residual = tf.math.divide(scaling*residual, scaling*pdfx)
                        pde_loss = (tf.reduce_mean(weight_residual) +
                                    args.lambda_bd * tf.reduce_mean(residual_boundary) +
                                    args.lambda_ic * tf.reduce_mean(residual_ic))

        return pde_loss, residual
        
        
    def get_pdf(self, x):
        log_pdfx = self.pdf_model(x)
        pdfx = tf.math.exp(log_pdfx)
        return pdfx


    def get_entropy_loss(self, quantity, pre_pdf, x):
        log_pdf = tf.clip_by_value(self.pdf_model(x), -23.02585, 5.0)

        # scaling for numerical stability
        scaling = 1000.0
        pre_pdf = scaling*pre_pdf
        quantity = scaling*quantity

        # importance sampling
        ratio = tf.math.divide(quantity, pre_pdf)
        res_time_logpdf = ratio*log_pdf
        entropy_loss = -tf.reduce_mean(res_time_logpdf)
        return entropy_loss


    @tf.function
    def get_slope(self, x):
        """
        compute slope for nn
        """
        with tf.GradientTape() as tape:
            unn = self.net_u(x)
            grads = pde_model_td.compute_grads(unn, x)
            slopes = tf.reduce_sum(tf.math.square(grads), axis=1, keepdims=True) 

        return slopes


    @tf.function
    def residual_for_flow(self, inputs, inputs_boundary, stage_idx, inputs_ic=None):
        with tf.GradientTape() as tape:
            pde_loss, residual = self.get_pde_loss(inputs, inputs_boundary, stage_idx, inputs_ic)
        return residual


    @tf.function
    def train_pde(self, inputs, inputs_boundary, i, net_u_training_vars, inputs_ic=None):
        """        
        Args:
        -----
            inputs: interior points, tensor of shape (n_samples, n_dim)
            inputs_boundary: boundary points, tensor of shape (n_samples, n_dim)
            inputs_ic: initial condition points, tensor of shape (n_samples, n_dimß)
            i: current stage index
            net_u_training_vars: trainable weights of solution network

        Returns:
        --------
            pde_loss: total loss
            residual: residual at interior points
        """
        with tf.GradientTape() as pde_tape:
            pde_loss, residual = self.get_pde_loss(
                inputs, inputs_boundary, i, inputs_ic)

        grads_net_u = pde_tape.gradient(pde_loss, net_u_training_vars)
        self.pde_optimizer.apply_gradients(zip(grads_net_u, net_u_training_vars))
        return pde_loss, residual


    @tf.function
    def train_flow(self, inputs, quantity, pre_pdf, pdf_training_vars):
        with tf.GradientTape() as ce_tape:
            entropy_loss = self.get_entropy_loss(quantity, pre_pdf, inputs)

        grads_pdf_model = ce_tape.gradient(entropy_loss, pdf_training_vars)
        self.flow_optimizer.apply_gradients(zip(grads_pdf_model, pdf_training_vars))
        return entropy_loss


    def solve_pde(self, train_dataset, stage_idx, sample_valid, u_true,
              train_dataset_boundary=None, train_dataset_ic=None):
        """
        train a neural network to approximate the pde solution

        Args:
        -----
            train_dataset: dataset of interior points
            train_dataset_boundary: dataset of boundary points 
            train_dataset_ic: dataset of IC points
            stage_idx: current stage index
            sample_valid: validation points
            u_true: true solution at validation points
            

        Returns:
        --------
            u_pred: predicted solution at validation points
            tol_pde: mean pde loss over last 5 iterations
            res_var: mean residual variance over last 5 iterations
        """
        args = self.args
        n_epochs = args.n_epochs

        for k in tf.range(1, n_epochs+1):

            
            for step, (batch_x, batch_boundary, batch_ic) in enumerate(
                    zip(train_dataset, train_dataset_boundary, train_dataset_ic)):

                pde_loss, residual = self.train_pde(
                    batch_x, batch_boundary, stage_idx,
                    self.net_u.trainable_weights, batch_ic)

                residual_loss     = tf.reduce_mean(residual)
                variance_residual = tf.math.reduce_variance(residual)
                
                
                # compute individual loss components
                if args.probsetup == 18:
                    bd_loss_val = tf.reduce_mean(
                        pde_model_td.boundary_loss_timedep_moving_transient(
                            self.net_u, batch_boundary, alpha=args.alpha))
                    ic_loss_val = tf.reduce_mean(
                        pde_model_td.ic_loss_timedep_moving_transient(
                            self.net_u, batch_ic))

                elif args.probsetup == 20:
                    bd_loss_val = tf.reduce_mean(
                        pde_model_td.boundary_loss_rotation(
                            self.net_u, batch_boundary, alpha=args.alpha))
                    ic_loss_val = tf.reduce_mean(
                        pde_model_td.ic_loss_rotation(
                            self.net_u, batch_ic, alpha=args.alpha))

                elif args.probsetup == 21:
                    bd_loss_val = tf.reduce_mean(
                        pde_model_td.boundary_loss_burgers(
                            self.net_u, batch_boundary, alpha=args.alpha))
                    ic_loss_val = tf.reduce_mean(
                        pde_model_td.ic_loss_burgers(
                            self.net_u, batch_ic, alpha=args.alpha))

                    
                elif args.probsetup == 22:
                    bd_loss_val = tf.reduce_mean(
                        pde_model_td.boundary_loss_timedep_hd_transient(
                            self.net_u, batch_boundary))
                    ic_loss_val = tf.reduce_mean(
                        pde_model_td.ic_loss_timedep_hd_transient(
                            self.net_u, batch_ic))

                elif args.probsetup == 23:
                    bd_loss_val = tf.reduce_mean(
                        pde_model_td.boundary_loss_advection_hd(
                            self.net_u, batch_boundary, alpha=args.alpha))
                    ic_loss_val = tf.reduce_mean(
                        pde_model_td.ic_loss_advection_hd(
                            self.net_u, batch_ic, alpha=args.alpha))


                print('stage: %s, epoch: %s, iter: %s, residual: %s, pde: %s, bd: %s, ic: %s' %
                        (stage_idx, k.numpy(), step+1, residual_loss.numpy(), pde_loss.numpy(),
                        bd_loss_val.numpy(), ic_loss_val.numpy()))
                self.pdeloss_vs_iter      += [pde_loss.numpy()]
                self.residualloss_vs_iter += [residual_loss.numpy()]
                self.resvar_vs_iter       += [variance_residual.numpy()]
                self.bdloss_vs_iter       += [bd_loss_val.numpy()]
                self.icloss_vs_iter       += [ic_loss_val.numpy()]

                # validation error
                if args.probsetup == 22:
                    u_pred = pde_model_td.apply_hard_constraint_hd_transient(
                        self.net_u, sample_valid)
                else:
                    u_pred = self.net_u(sample_valid)

                # mean square error
                approximate_error = tf.reduce_mean(tf.math.square(u_true - u_pred))
                self.approximate_error_vs_iter += [approximate_error.numpy()]

                # relative L2 error
                rel_l2 = tf.sqrt(tf.reduce_sum(tf.math.square(u_true - u_pred))) \
                    / tf.sqrt(tf.reduce_sum(tf.math.square(u_true)))
                self.rel_l2_vs_iter += [rel_l2.numpy()]

                # L_inf error
                l_inf = tf.reduce_max(tf.abs(u_true - u_pred))
                self.linf_vs_iter   += [l_inf.numpy()]

            # save checkpoint every ckpt_step epochs
            self.ckpt.step.assign_add(1)
            if int(self.ckpt.step) % args.ckpt_step == 0:
                save_path = self.manager.save()
                print("Saved checkpoint for step {}: {}".format(int(self.ckpt.step), save_path))

        tol_pde = np.mean(np.array(self.pdeloss_vs_iter[-5:]))
        res_var = np.mean(np.array(self.resvar_vs_iter[-5:]))

        return u_pred, tol_pde, res_var
    
    
    def solve_flow(self, train_dataset, i):
        """
        train the flow model (KRnet) to learn the residual density

        Args:
        -----
            train_dataset: dataset of interior points
            i: current stage index
        """
        args = self.args
        flow_epochs = args.flow_epochs

        for k in tf.range(1, flow_epochs+1):
            for step, batch_x in enumerate(train_dataset):
                if i == 1:
                    batch_x_data = batch_x
                else:
                    batch_x_data  = batch_x[:, :args.n_dim]
                    batch_pre_pdf = tf.reshape(batch_x[:, -1], [-1, 1])

                # generate boundary and IC points for residual computation
                if args.probsetup == 18  or args.probsetup == 20 \
                        or args.probsetup == 21:
                    batch_boundary = BR_data.gen_spacetime_boundary(args.flow_batch_size)
                    batch_ic       = BR_data.gen_spacetime_ic(args.flow_batch_size)
                    batch_boundary = tf.cast(batch_boundary, tf.float32)
                    batch_ic       = tf.cast(batch_ic, tf.float32)

                elif args.probsetup == 22 or args.probsetup == 23:
                    batch_boundary = BR_data.gen_nd_cube_boundary_spacetime(
                        args.n_dim, args.flow_batch_size)
                    batch_ic       = BR_data.gen_spacetime_ic_nd(
                        args.n_dim, args.flow_batch_size)
                    batch_boundary = tf.cast(batch_boundary, tf.float32)
                    batch_ic       = tf.cast(batch_ic, tf.float32)

                # compute quantity for adaptivity (residual or slope)
                if args.quantity_type == 'slope':
                    quantity = self.get_slope(batch_x_data)
                    quantity = args.scale_quantity * quantity
                else:
                    quantity = self.residual_for_flow(
                        batch_x_data, batch_boundary, i, batch_ic)
                    quantity = args.scale_quantity * quantity

                if i == 1:
                    pre_pdf      = tf.ones_like(quantity, dtype=tf.float32)
                    entropy_loss = self.train_flow(batch_x_data, quantity, pre_pdf,
                                                   self.pdf_model.trainable_weights)
                else:
                    entropy_loss = self.train_flow(batch_x_data, quantity, batch_pre_pdf,
                                                   self.pdf_model.trainable_weights)

                quantity_loss = tf.reduce_mean(quantity)
                print('stage: %s, flow_epoch: %s, iter: %s, quantity: %s, entropy_loss: %s ' %
                      (i, k.numpy(), step+1, quantity_loss.numpy(), entropy_loss.numpy()))

                self.entropyloss_vs_iter += [entropy_loss.numpy()]

    def train(self):
        """training procedure"""
        args = self.args
        max_stage = args.max_stage

        # load validation data
        sample_valid, u_true = load_valid_data(args.n_dim, args.probsetup, alpha=args.alpha, store_dir=args.data_dir)

        # summary writer
        summary_writer = tf.summary.create_file_writer(args.summary_dir)

        print(' Quantity type for adaptive procedure: %s' % (args.quantity_type))
        print('====== Training process starting... ======')

        with summary_writer.as_default():

            # set random seed
            np.random.seed(23)
            tf.random.set_seed(23)

            
            # generate initial training data - three separate arrays
            x_data, x_boundary, x_ic = gen_train_data(
                args.n_dim, args.n_train, args.probsetup)

            # strictly enforce equal sizes
            n_pts      = min(x_data.shape[0], x_boundary.shape[0], x_ic.shape[0])
            x_data     = x_data[:n_pts, :]
            x_boundary = x_boundary[:n_pts, :]
            x_ic       = x_ic[:n_pts, :]


            # save initial uniform training points for visualization
            np.savetxt(os.path.join(args.data_dir, 'stage_0_interior.dat'), x_data)
            np.savetxt(os.path.join(args.data_dir, 'stage_0_boundary.dat'), x_boundary)
            np.savetxt(os.path.join(args.data_dir, 'stage_0_ic.dat'), x_ic)
            print('Initial training points saved.')

            # create three separate datasets for PDE training
            data_flow_interior = BR_data.dataflow(x_data,
                                                    buffersize=n_pts,
                                                    batchsize=args.batch_size)
            data_flow_boundary = BR_data.dataflow(x_boundary,
                                                    buffersize=n_pts,
                                                    batchsize=args.batch_size)
            data_flow_ic       = BR_data.dataflow(x_ic,
                                                    buffersize=n_pts,
                                                    batchsize=args.batch_size)

            train_dataset_interior = data_flow_interior.get_shuffled_batched_dataset()
            train_dataset_boundary = data_flow_boundary.get_shuffled_batched_dataset()
            train_dataset_ic       = data_flow_ic.get_shuffled_batched_dataset()

            # create flow dataset for KRnet - interior points only
            data_flow_kr       = BR_data.dataflow(x_data,
                                                    buffersize=n_pts,
                                                    batchsize=args.flow_batch_size)
            train_dataset_flow = data_flow_kr.get_shuffled_batched_dataset()

            # initialize networks by passing a batch of data
            m = 1
            x_init_kr = data_flow_kr.get_n_batch_from_shuffled_batched_dataset(m)
            self.net_u(x_init_kr)
            self.pdf_model(x_init_kr)
            if args.rotation:
                self.pdf_model.WLU_data_initialization()
            self.pdf_model.actnorm_data_initialization()

            for i in range(1, max_stage+1):

                # solve PDE with three separate datasets
                u_pred, tol_pde, res_var = self.solve_pde(
                    train_dataset_interior, i, sample_valid, u_true,
                    train_dataset_boundary, train_dataset_ic)

                if tol_pde < args.tol and res_var < args.tol and i > 1:
                    print('===== stopping criterion satisfies, finish training =====')
                    break

                if i < max_stage:

                    # train KRnet 
                    self.solve_flow(train_dataset_flow, i)

                    # resample - returns three separate arrays
                    x_interior_new, x_boundary_new, x_ic_new = self.resample()

                    # strictly enforce equal sizes after resample
                    n_new          = min(x_interior_new.shape[0],
                                        x_boundary_new.shape[0],
                                        x_ic_new.shape[0])
                    x_interior_new = x_interior_new[:n_new, :]
                    x_boundary_new = x_boundary_new[:n_new, :]
                    x_ic_new       = x_ic_new[:n_new, :]

                    if args.replace_all == 1:
                        # DAS-R: replace all samples

                        # update three PDE datasets
                        data_flow_interior = BR_data.dataflow(x_interior_new,
                                                                buffersize=n_new,
                                                                batchsize=args.batch_size)
                        data_flow_boundary = BR_data.dataflow(x_boundary_new,
                                                                buffersize=n_new,
                                                                batchsize=args.batch_size)
                        data_flow_ic       = BR_data.dataflow(x_ic_new,
                                                                buffersize=n_new,
                                                                batchsize=args.batch_size)

                        train_dataset_interior = data_flow_interior.get_shuffled_batched_dataset()
                        train_dataset_boundary = data_flow_boundary.get_shuffled_batched_dataset()
                        train_dataset_ic       = data_flow_ic.get_shuffled_batched_dataset()

                        # DAS-R flow dataset: keep resampling until we have
                        # enough valid interior points
                        x_flow_int = np.zeros((0, args.n_dim), dtype=np.float32)
                        tol = 1e-6

                        while x_flow_int.shape[0] < n_new:
                            n_needed     = n_new - x_flow_int.shape[0]
                            x_prior_flow = self.pdf_model.draw_samples_from_prior(
                                n_needed, args.n_dim)
                            x_flow_cand  = self.pdf_model.mapping_from_prior(
                                x_prior_flow).numpy()

                            # project and filter
                            x_flow_inside, x_flow_proj = \
                                BR_data.projection_onto_infunitball(x_flow_cand)

                            # recover valid interior points from projected set
                            if x_flow_proj.shape[0] > 0:
                                if args.probsetup == 18 or args.probsetup == 20\
                                        or args.probsetup == 21:
                                    ic_mask_flow  = (x_flow_proj[:, 2] == -1.0)
                                    sp_mask_flow  = (
                                        ((np.abs(x_flow_proj[:, 0]) == 1.0) |
                                        (np.abs(x_flow_proj[:, 1]) == 1.0)) &
                                        (~ic_mask_flow)
                                    )
                                else:
                                    ic_mask_flow = (np.abs(x_flow_proj[:, -1] + 1.0) < tol)
                                    sp_mask_spatial = np.zeros(
                                        x_flow_proj.shape[0], dtype=bool)
                                    for j in range(args.n_dim - 1):
                                        sp_mask_spatial |= (
                                            np.abs(x_flow_proj[:, j]) > 1.0 - tol)
                                    sp_mask_flow = sp_mask_spatial & (~ic_mask_flow)

                                int_mask_flow = (~ic_mask_flow) & (~sp_mask_flow)
                                x_flow_inside = np.concatenate(
                                    (x_flow_inside,
                                        x_flow_proj[int_mask_flow, :]),
                                    axis=0)

                            x_flow_int = np.concatenate(
                                (x_flow_int, x_flow_inside), axis=0)

                        # trim exactly to n_new
                        x_flow_int = x_flow_int[:n_new, :]

                        # attach pre_pdf
                        pre_pdf = tf.clip_by_value(
                            self.get_pdf(x_flow_int), 1.0e-10, 148.4131)
                        pre_pdf = tf.stop_gradient(pre_pdf).numpy()
                        x_flow  = np.concatenate((x_flow_int, pre_pdf), axis=1)

                        data_flow_kr       = BR_data.dataflow(
                            x_flow,
                            buffersize=x_flow.shape[0],
                            batchsize=args.flow_batch_size)
                        train_dataset_flow = data_flow_kr.get_shuffled_batched_dataset()

                    else:
                        # DAS-G: grow all samples

                        x_data     = np.concatenate((x_data, x_interior_new), axis=0)
                        x_boundary = np.concatenate((x_boundary, x_boundary_new), axis=0)
                        x_ic       = np.concatenate((x_ic, x_ic_new), axis=0)

                        # strictly enforce equal sizes after growth
                        n_grown    = min(x_data.shape[0],
                                        x_boundary.shape[0],
                                        x_ic.shape[0])
                        x_data     = x_data[:n_grown, :]
                        x_boundary = x_boundary[:n_grown, :]
                        x_ic       = x_ic[:n_grown, :]

                        # update three PDE datasets
                        data_flow_interior = BR_data.dataflow(x_data,
                                                                buffersize=n_grown,
                                                                batchsize=args.batch_size)
                        data_flow_boundary = BR_data.dataflow(x_boundary,
                                                                buffersize=n_grown,
                                                                batchsize=args.batch_size)
                        data_flow_ic       = BR_data.dataflow(x_ic,
                                                                buffersize=n_grown,
                                                                batchsize=args.batch_size)

                        train_dataset_interior = data_flow_interior.get_shuffled_batched_dataset()
                        train_dataset_boundary = data_flow_boundary.get_shuffled_batched_dataset()
                        train_dataset_ic       = data_flow_ic.get_shuffled_batched_dataset()

                        # DAS-G flow dataset: use current full interior set x_data
                        pre_pdf = tf.clip_by_value(
                            self.get_pdf(x_data), 1.0e-10, 148.4131)
                        pre_pdf = tf.stop_gradient(pre_pdf).numpy()
                        x_flow  = np.concatenate((x_data, pre_pdf), axis=1)

                        data_flow_kr       = BR_data.dataflow(
                            x_flow,
                            buffersize=x_flow.shape[0],
                            batchsize=args.flow_batch_size)
                        train_dataset_flow = data_flow_kr.get_shuffled_batched_dataset()

                    # save resampled points for all three sets
                    np.savetxt(os.path.join(args.data_dir,
                                'stage_{}_resample_interior.dat'.format(i)),
                                x_interior_new)
                    np.savetxt(os.path.join(args.data_dir,
                                'stage_{}_resample_boundary.dat'.format(i)),
                                x_boundary_new)
                    np.savetxt(os.path.join(args.data_dir,
                                'stage_{}_resample_ic.dat'.format(i)),
                                x_ic_new)



            # save training history
            np.savetxt(os.path.join(args.data_dir, 'pdeloss_vs_iter.dat'),
                       np.array(self.pdeloss_vs_iter))
            np.savetxt(os.path.join(args.data_dir, 'residualloss_vs_iter.dat'),
                       np.array(self.residualloss_vs_iter))
            validation_error = np.array(self.approximate_error_vs_iter).reshape(-1, 1)
            np.savetxt(os.path.join(args.data_dir, 'validation_error.dat'),
                       validation_error)
            np.savetxt(os.path.join(args.data_dir, 'rel_l2_vs_iter.dat'),
                    np.array(self.rel_l2_vs_iter))
            np.savetxt(os.path.join(args.data_dir, 'linf_vs_iter.dat'),
                    np.array(self.linf_vs_iter))            
            np.savetxt(os.path.join(args.data_dir, 'u_true.dat'), u_true)
            np.savetxt(os.path.join(args.data_dir, 'u_pred.dat'), u_pred)
            if args.max_stage > 1:
                np.savetxt(os.path.join(args.data_dir, 'entropyloss_vs_iter.dat'),
                           np.array(self.entropyloss_vs_iter))
            # save boundary and IC loss for time-dependent problems
            np.savetxt(os.path.join(args.data_dir, 'bdloss_vs_iter.dat'),
                        np.array(self.bdloss_vs_iter))
            np.savetxt(os.path.join(args.data_dir, 'icloss_vs_iter.dat'),
                        np.array(self.icloss_vs_iter))