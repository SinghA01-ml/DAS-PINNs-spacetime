# File: pde_model_td.py
# Author: Anshima Singh, June 2026
# Description: Time-dependent PDE model definitions — extension of pde_model.py
#              Includes exact solutions, source functions, pde loss,
#               boundary loss, and initial loss for time-dependent problems.
# Note: This file extends the steady-state framework of pde_model.py
#       (original author: Kejun Tang, github.com/MJfadeaway/DAS)
#       No original code from pde_model.py is reused here.

from __future__ import absolute_import, division, print_function, unicode_literals
import tensorflow as tf
import numpy as np
from scipy.special import expit


################################################################################
# PROBSETUP = 18 - Transient Gaussian peak problem
################################################################################

def exact_timedep_moving_transient(x, c=0.5, x0=-0.5, y0=0.0,
                                    lam=5.0, T=1.0, alpha=100.0):
    """
    Exact solution for moving transient Gaussian peak problem:
    u(x1, x2, t) = exp(-alpha*[(x1-x0-c*t)^2 + (x2-y0)^2]) * (1 - exp(-lam*t))

    Args:
    -----
        x: numpy array of shape (n_samples, 3)
           columns: [x1, x2, t_normalized]
        c: velocity of peak
        x0: initial x1 center of peak
        y0: initial x2 center of peak
        lam: rate parameter controlling approach to steady state
        T: final time
        alpha: Gaussian coefficient

    Returns:
    --------
        u: exact solution, numpy array of shape (n_samples, 1)
    """
    x1           = x[:, 0]
    x2           = x[:, 1]
    t_normalized = x[:, 2]

    # denormalize time
    t_original = (t_normalized + 1.0) / 2.0 * T

    S = (x1 - x0 - c*t_original)**2 + (x2 - y0)**2
    u = np.exp(-alpha * S) * (1.0 - np.exp(-lam * t_original))
    u = np.reshape(u, (-1, 1))
    return u


def f_source_timedep_moving_transient(x, c=0.5, x0=-0.5, y0=0.0,
                                       lam=5.0, T=1.0, alpha=10.0):
    """
    Source term for moving transient Gaussian peak problem

    Args:
    -----
        x: tensor of shape (n_samples, 3)
           columns: [x1, x2, t_normalized]
        c: velocity of peak
        x0: initial x1 center
        y0: initial x2 center
        lam: rate parameter
        T: final time
        alpha: Gaussian coefficient

    Returns:
    --------
        f: source term, tensor of shape (n_samples, 1)
    """

    x1           = tf.reshape(x[:, 0], [-1, 1])
    x2           = tf.reshape(x[:, 1], [-1, 1])
    t_normalized = x[:, 2:3]

    # denormalize time
    t_original = (t_normalized + 1.0) / 2.0 * T

    S     = (x1 - x0 - c*t_original)**2 + (x2 - y0)**2
    G     = tf.math.exp(-alpha * S)
    F     = 1.0 - tf.math.exp(-lam * t_original)
    decay = tf.math.exp(-lam * t_original)

    f = G * (lam * decay + F * (2.0*alpha*c*(x1 - x0 - c*t_original)
                                + 4.0*alpha - 4.0*alpha**2*S))
    return f


def residual_timedep_moving_transient(model, x, c=0.5, x0=-0.5, y0=0.0,
                                       lam=5.0, T=1.0, alpha=10.0):
    """
    TF format
    Residual for moving transient Gaussian peak problem:

    Args:
    -----
        model: PINN network
        x: tensor of shape (n_samples, 3)
           columns: [x1, x2, t_normalized]
        c: velocity of peak
        x0: initial x1 center
        y0: initial x2 center
        lam: rate parameter
        T: final time
        alpha: Gaussian coefficient

    Returns:
    --------
        residual: squared residual, tensor of shape (n_samples, 1)
    """
    with tf.GradientTape(persistent=True) as tape2:
        tape2.watch(x)
        with tf.GradientTape() as tape1:
            tape1.watch(x)
            u = model(x)
        grads            = tape1.gradient(u, x)
        du_dx1           = grads[:, 0:1]
        du_dx2           = grads[:, 1:2]
        du_dt_normalized = grads[:, 2:3]

    d2u_dx1 = tape2.gradient(du_dx1, x)[:, 0:1]
    d2u_dx2 = tape2.gradient(du_dx2, x)[:, 1:2]

    del tape2

    # chain rule
    du_dt_original = du_dt_normalized * (2.0 / T)
    laplacian      = d2u_dx1 + d2u_dx2

    f = f_source_timedep_moving_transient(x, c=c, x0=x0, y0=y0,
                                           lam=lam, T=T, alpha=alpha)

    residual = tf.math.square(du_dt_original - laplacian - f)
    return residual


def boundary_loss_timedep_moving_transient(model, x_boundary,
                                            c=0.5, x0=-0.5, y0=0.0,
                                            lam=5.0, T=1.0, alpha=10.0):
    """
    TF format
    Boundary loss for moving transient Gaussian peak problem.

    Args:
    -----
        model: PINN network
        x_boundary: tensor of shape (n_samples, 3)
                    columns: [x1, x2, t_normalized]
        c: velocity of peak
        x0: initial x1 center
        y0: initial x2 center
        lam: rate parameter
        T: final time
        alpha: Gaussian coefficient

    Returns:
    --------
        residual_boundary: squared error, tensor of shape (n_samples, 1)
    """
    x1           = tf.reshape(x_boundary[:, 0], [-1, 1])
    x2           = tf.reshape(x_boundary[:, 1], [-1, 1])
    t_normalized = x_boundary[:, 2:3]

    t_original = (t_normalized + 1.0) / 2.0 * T

    S       = (x1 - x0 - c*t_original)**2 + (x2 - y0)**2
    u_exact = tf.math.exp(-alpha * S) * (1.0 - tf.math.exp(-lam * t_original))

    u_pred            = model(x_boundary)
    residual_boundary = tf.math.square(u_pred - u_exact)
    return residual_boundary


def ic_loss_timedep_moving_transient(model, x_ic):
    """
    TF format
    IC loss for moving transient Gaussian peak problem.
    At t=0: u(x,0) = 0 everywhere

    Args:
    -----
        model: PINN network
        x_ic: tensor of shape (n_samples, 3)
              columns: [x1, x2, t_normalized] where t_normalized=-1

    Returns:
    --------
        residual_ic: squared error at t=0, tensor of shape (n_samples, 1)
    """
    u_exact_ic  = tf.zeros([tf.shape(x_ic)[0], 1], dtype=tf.float32)
    u_pred      = model(x_ic)
    residual_ic = tf.math.square(u_pred - u_exact_ic)
    return residual_ic


################################################################################################################################################################################################################################


################################################################################
# PROBSETUP = 20 - A rotating peak problem
################################################################################

def exact_rotation(x, alpha=0.01, T=1.0):
    """
    Numpy format.
    Exact solution for rotation equation:
    u(x1, x2, t) = exp[-(1/alpha)*{(x1-cos(t))^2 + (x2-sin(t))^2)}]


    Args:
    -----
        x: numpy array of shape (n_samples, 3)
           columns: [x1, x2, t_normalized]
        alpha: Gaussian width coefficient (alpha=0.01)
        T: final time

    Returns:
    --------
        u: exact solution, numpy array of shape (n_samples, 1)
    """
    x1           = x[:, 0]
    x2           = x[:, 1]
    t_normalized = x[:, 2]

    # denormalize time: t_normalized in [-1,1] -> t_original in [0,T]
    t_original = (t_normalized + 1.0) / 2.0 * T

    S = (x1 - np.cos(t_original))**2 + (x2 - np.sin(t_original))**2
    u = np.exp(-(1.0 / alpha) * S)
    u = np.reshape(u, (-1, 1))
    return u


def residual_rotation(model, x, alpha=0.01, T=1.0):
    """
    TF format.
    Residual for rotation equation (pure transport, no source term)
    Only first-order derivatives needed - single GradientTape sufficient.

    Args:
    -----
        model: PINN network
        x: tensor of shape (n_samples, 3)
           columns: [x1, x2, t_normalized]
        alpha: Gaussian width coefficient (alpha=0.01)
        T: final time

    Returns:
    --------
        residual: squared residual, tensor of shape (n_samples, 1)
    """
    t_normalized = x[:, 2:3]
    t_original   = (t_normalized + 1.0) / 2.0 * T

    with tf.GradientTape() as tape:
        tape.watch(x)
        u = model(x)
    grads            = tape.gradient(u, x)   # shape (n_samples, 3)
    du_dx1           = grads[:, 0:1]          
    du_dx2           = grads[:, 1:2]         
    du_dt_normalized = grads[:, 2:3]          

    du_dt_original = du_dt_normalized * (2.0 / T)

    pde_residual = (du_dt_original
                    - du_dx1 * tf.math.sin(t_original)
                    + du_dx2 * tf.math.cos(t_original))

    residual = tf.math.square(pde_residual)
    return residual


def boundary_loss_rotation(model, x_boundary, alpha=0.01, T=1.0):
    """
    TF format.
    Boundary loss for rotation equation.

    Args:
    -----
        model: PINN network
        x_boundary: tensor of shape (n_samples, 3)
                    columns: [x1, x2, t_normalized]
        alpha: Gaussian width coefficient (alpha=0.01)
        T: final time

    Returns:
    --------
        residual_boundary: squared error, tensor of shape (n_samples, 1)
    """
    x1           = x_boundary[:, 0:1]
    x2           = x_boundary[:, 1:2]
    t_normalized = x_boundary[:, 2:3]

    t_original = (t_normalized + 1.0) / 2.0 * T

    S       = (x1 - tf.math.cos(t_original))**2 + (x2 - tf.math.sin(t_original))**2
    u_exact = tf.math.exp(-(1.0 / alpha) * S)

    u_pred            = model(x_boundary)
    residual_boundary = tf.math.square(u_pred - u_exact)
    return residual_boundary


def ic_loss_rotation(model, x_ic, alpha=0.1):
    """
    TF format.
    IC loss for rotation equation.
    At t=0: u(x1, x2, 0) = exp(-(1/alpha)*((x1-1)^2 + x2^2))

    Args:
    -----
        model: PINN network
        x_ic: tensor of shape (n_samples, 3)
              columns: [x1, x2, t_normalized] where t_normalized = -1
        alpha: Gaussian width coefficient

    Returns:
    --------
        residual_ic: squared error at t=0, tensor of shape (n_samples, 1)
    """
    x1 = x_ic[:, 0:1]
    x2 = x_ic[:, 1:2]
    # t_normalized = -1 means t_original = 0
    S          = (x1 - 1.0)**2 + x2**2
    u_exact_ic = tf.math.exp(-(1.0 / alpha) * S)

    u_pred      = model(x_ic)
    residual_ic = tf.math.square(u_pred - u_exact_ic)
    return residual_ic


##################################################################################################################################################################################

################################################################################
# PROBSETUP = 21 - A nonlinear problem (viscous Burgers’ equation)
################################################################################

def exact_burgers(x, alpha=0.001, T=1.0):
    """
    Numpy format.
    Exact solution for 2D Burgers equation:
    u(x1, x2, t) = 1 / (1 + exp((x1+x2-t)/2alpha))

    Args:
    -----
        x: numpy array of shape (n_samples, 3)
           columns: [x1, x2, t_normalized]
        alpha: viscosity coefficient (alpha=0.001)
        T: final time

    Returns:
    --------
        u: exact solution, numpy array of shape (n_samples, 1)
    """
    x1           = x[:, 0]
    x2           = x[:, 1]
    t_normalized = x[:, 2]

    # denormalize time
    t_original = (t_normalized + 1.0) / 2.0 * T

    # expit(z) = 1/(1+exp(-z)) = sigmoid(z)
    # so expit(-exponent) = 1/(1+exp(exponent)) - numerically stable
    exponent = (x1 + x2 - t_original) / (2.0 * alpha)
    u = expit(-exponent)
    u = np.reshape(u, (-1, 1))
    return u


def residual_burgers(model, x, alpha=0.001, T=1.0):
    """
    TF format.
    Residual for 2D Burgers equation

    Args:
    -----
        model: PINN network
        x: tensor of shape (n_samples, 3)
           columns: [x1, x2, t_normalized]
        alpha: viscosity coefficient (alpha=0.001)
        T: final time

    Returns:
    --------
        residual: squared residual, tensor of shape (n_samples, 1)
    """
    with tf.GradientTape(persistent=True) as tape2:
        tape2.watch(x)
        with tf.GradientTape() as tape1:
            tape1.watch(x)
            u = model(x)
        grads            = tape1.gradient(u, x)
        du_dx1           = grads[:, 0:1]     
        du_dx2           = grads[:, 1:2]       
        du_dt_normalized = grads[:, 2:3]     

    d2u_dx1 = tape2.gradient(du_dx1, x)[:, 0:1]  
    d2u_dx2 = tape2.gradient(du_dx2, x)[:, 1:2]  
    del tape2

    du_dt_original = du_dt_normalized * (2.0 / T)

    laplacian   = d2u_dx1 + d2u_dx2
    nonlin_term = u * (du_dx1 + du_dx2)

    pde_residual = du_dt_original - alpha * laplacian + nonlin_term

    residual = tf.math.square(pde_residual)
    return residual


def boundary_loss_burgers(model, x_boundary, alpha=0.001, T=1.0):
    """
    TF format.
    Boundary loss for 2D Burgers equation.

    Args:
    -----
        model: PINN network
        x_boundary: tensor of shape (n_samples, 3)
                    columns: [x1, x2, t_normalized]
        alpha: viscosity coefficient (alpha=0.001)
        T: final time

    Returns:
    --------
        residual_boundary: squared error, tensor of shape (n_samples, 1)
    """
    x1           = x_boundary[:, 0:1]
    x2           = x_boundary[:, 1:2]
    t_normalized = x_boundary[:, 2:3]

    t_original = (t_normalized + 1.0) / 2.0 * T

    # sigmoid(-exponent) = 1/(1+exp(exponent)) - numerically stable
    exponent = (x1 + x2 - t_original) / (2.0 * alpha)
    u_exact  = tf.math.sigmoid(-exponent)

    u_pred            = model(x_boundary)
    residual_boundary = tf.math.square(u_pred - u_exact)
    return residual_boundary


def ic_loss_burgers(model, x_ic, alpha=0.001):
    """
    TF format.
    IC loss for 2D Burgers equation.

    Args:
    -----
        model: PINN network
        x_ic: tensor of shape (n_samples, 3)
              columns: [x1, x2, t_normalized] where t_normalized=-1
        alpha: viscosity coefficient (alpha=0.001)

    Returns:
    --------
        residual_ic: squared error at t=0, tensor of shape (n_samples, 1)
    """
    x1 = x_ic[:, 0:1]
    x2 = x_ic[:, 1:2]
    # t_normalized = -1 means t_original=0

    exponent   = (x1 + x2) / (2.0 * alpha)
    u_exact_ic = tf.math.sigmoid(-exponent)

    u_pred      = model(x_ic)
    residual_ic = tf.math.square(u_pred - u_exact_ic)
    return residual_ic


################################################################################################################################################################################################################################

################################################################################
# PROBSETUP = 22 - A high-dimensional parabolic problem
################################################################################


def apply_hard_constraint_hd_transient(model, x, lam=5.0, T=1.0):
    """
    TF format.
    Hard constraint wrapper for high-dimensional transient Gaussian peak.
    Exactly enforces zero IC by construction:
        u_tilde(x, t) = t * u_NN(x, t)
    At t=0: factor = 0 so u_tilde = 0 exactly.

    Args:
    -----
        model: PINN network
        x: tensor of shape (n_samples, d+1)
           columns: [x1, x2, ..., xd, t_normalized]
        lam: rate parameter (default 5.0)
        T: final time (default 1.0)

    Returns:
    --------
        u_tilde: hard-constrained output, tensor of shape (n_samples, 1)
    """
    t_normalized = x[:, -1:]
    t_original   = (t_normalized + 1.0) / 2.0 * T
    return t_original * model(x)


def exact_timedep_hd_transient(x, lam=5.0, T=1.0):
    """
    Numpy format.
    Exact solution for high-dimensional transient Gaussian peak:
        u(x, t) = exp(-10 * ||x||^2) * (1 - exp(-lam * t))

    Args:
    -----
        x: numpy array of shape (n_samples, d+1)
           columns: [x1, x2, ..., xd, t_normalized]
           where t_normalized in [-1, 1]
        lam: rate parameter controlling approach to steady state (default 5.0)
        T: final time (default 1.0)

    Returns:
    --------
        u: exact solution, numpy array of shape (n_samples, 1)
    """
    x_spatial    = x[:, :-1]       # (n_samples, d) - all columns except last
    t_normalized = x[:, -1]        # (n_samples,)   - last column is time

    # denormalize time: t_normalized in [-1,1] -> t_original in [0,T]
    t_original = (t_normalized + 1.0) / 2.0 * T

    x_norm_sq = np.sum(x_spatial**2, axis=1)   # (n_samples,)
    G = np.exp(-10.0 * x_norm_sq)
    u = G * (1.0 - np.exp(-lam * t_original))
    u = np.reshape(u, (-1, 1))
    return u


def f_source_timedep_hd_transient(x, lam=5.0, T=1.0):
    """
    TF format.
    Source term for high-dimensional transient Gaussian peak

    Args:
    -----
        x: tensor of shape (n_samples, d+1)
           columns: [x1, x2, ..., xd, t_normalized]
        lam: rate parameter (default 5.0)
        T: final time (default 1.0)

    Returns:
    --------
        f: source term, tensor of shape (n_samples, 1)
    """
    x_spatial    = x[:, :-1]      
    t_normalized = x[:, -1:]      

    # denormalize time
    t_original = (t_normalized + 1.0) / 2.0 * T

    n_dim     = x_spatial.shape[-1]   
    x_norm_sq = tf.reduce_sum(
        tf.math.square(x_spatial), axis=1, keepdims=True)  # (n_samples, 1)

    G         = tf.math.exp(-10.0 * x_norm_sq)
    decay     = tf.math.exp(-lam * t_original)            
    transient = 1.0 - decay                              

    f = G * (lam * decay
             + (20.0 * tf.cast(n_dim, tf.float32) - 400.0 * x_norm_sq) * transient)
    return f


def residual_timedep_hd_transient(model, x, lam=5.0, T=1.0):
    """
    TF format.
    Residual for high-dimensional transient Gaussian peak

    Args:
    -----
        model: PINN network
        x: tensor of shape (n_samples, d+1)
           columns: [x1, x2, ..., xd, t_normalized]
        lam: rate parameter (default 5.0)
        T: final time (default 1.0)

    Returns:
    --------
        residual: squared residual, tensor of shape (n_samples, 1)
    """
    n_dim = x.shape[-1] - 1    # spatial dimension d

    with tf.GradientTape(persistent=True) as tape2:
        tape2.watch(x)
        with tf.GradientTape() as tape1:
            tape1.watch(x)
            u = apply_hard_constraint_hd_transient(model, x)
        grads = tape1.gradient(u, x)              
        grads_unstacked  = tf.unstack(grads[:, :n_dim], axis=1)   
        du_dt_normalized = grads[:, -1:]         

    laplacian = tf.zeros_like(u)
    for i in range(n_dim):
        grad2    = tape2.gradient(grads_unstacked[i], x)  
        d2u_dxi  = grad2[:, i:i+1]                       
        laplacian = laplacian + d2u_dxi

    del tape2

    du_dt_original = du_dt_normalized * (2.0 / T)

    f = f_source_timedep_hd_transient(x, lam=lam, T=T)

    pde_residual = du_dt_original - laplacian - f
    residual     = tf.math.square(pde_residual)
    return residual


def boundary_loss_timedep_hd_transient(model, x_boundary, lam=5.0, T=1.0):
    """
    TF format.
    Boundary loss for high-dimensional transient Gaussian peak.

    Args:
    -----
        model: PINN network
        x_boundary: tensor of shape (n_samples, d+1)
                    columns: [x1, x2, ..., xd, t_normalized]
        lam: rate parameter (default 5.0)
        T: final time (default 1.0)

    Returns:
    --------
        residual_boundary: squared error, tensor of shape (n_samples, 1)
    """
    x_spatial    = x_boundary[:, :-1]   
    t_normalized = x_boundary[:, -1:]   

    # denormalize time
    t_original = (t_normalized + 1.0) / 2.0 * T

    x_norm_sq = tf.reduce_sum(
        tf.math.square(x_spatial), axis=1, keepdims=True)  

    u_exact = (tf.math.exp(-10.0 * x_norm_sq) *
               (1.0 - tf.math.exp(-lam * t_original)))

    u_pred            = apply_hard_constraint_hd_transient(model, x_boundary)
    residual_boundary = tf.math.square(u_pred - u_exact)
    return residual_boundary


def ic_loss_timedep_hd_transient(model, x_ic):
    """
    TF format.
    IC loss for high-dimensional transient Gaussian peak.
    At t=0 (t_normalized=-1): u(x, 0) = 0 everywhere.

    Args:
    -----
        model: PINN network
        x_ic: tensor of shape (n_samples, d+1)
              columns: [x1, x2, ..., xd, t_normalized] where t_normalized=-1

    Returns:
    --------
        residual_ic: squared error at t=0, tensor of shape (n_samples, 1)
    """
    # hard constraint exactly enforces zero IC - no penalty needed
    residual_ic = tf.zeros([tf.shape(x_ic)[0], 1], dtype=tf.float32)
    return residual_ic



################################################################################################################################################################################################################################

################################################################################
# PROBSETUP = 23 — A high-dimensional hyperbolic problem (advection equation)
################################################################################


def exact_advection_hd(x, alpha=0.1, T=1.0):
    """
    Numpy format.
    Exact solution for high-dimensional advection equation:
        u(x, t) = exp(-1/alpha * sum_i (xi - t)^2)

    Domain: Omega = (-0.2, 1.2)^d
    Normalized input: xi' in [-1,1], t_norm in [-1,1]
    Denormalization: xi = 0.7*xi' + 0.5, t = (t_norm+1)/2

    Args:
    -----
        x: numpy array of shape (n_samples, d+1)
           columns: [x1', x2', ..., xd', t_normalized]
        alpha: Gaussian coefficient (default 0.1)
        T: final time 

    Returns:
    --------
        u: exact solution, numpy array of shape (n_samples, 1)
    """
    x_spatial_norm = x[:, :-1]          # (n_samples, d) - normalized
    t_normalized   = x[:, -1]           # (n_samples,)

    # denormalize
    x_spatial = 0.7 * x_spatial_norm + 0.5   # xi in (-0.2, 1.2)
    t_original = (t_normalized + 1.0) / 2.0 * T

    norm_sq = np.sum((x_spatial - t_original[:, None])**2, axis=1)
    u = np.exp(-(1.0 / alpha) * norm_sq)
    u = np.reshape(u, (-1, 1))
    return u


def residual_advection_hd(model, x, alpha=0.1, T=1.0):
    """
    TF format.
    Residual for high-dimensional advection equation in normalized coords


    Args:
    -----
        model: PINN network
        x: tensor of shape (n_samples, d+1)
           columns: [x1', ..., xd', t_normalized]
        alpha: Gaussian coefficient (alpha=0.1)
        T: final time

    Returns:
    --------
        residual: squared residual, tensor of shape (n_samples, 1)
    """
    n_dim = x.shape[-1] - 1    # spatial dimension d

    with tf.GradientTape() as tape:
        tape.watch(x)
        u = model(x)
    grads = tape.gradient(u, x)           # shape (N, d+1)

    du_dt_norm = grads[:, -1:]            # (N, 1)
    du_dxi_sum = tf.reduce_sum(
        grads[:, :n_dim], axis=1, keepdims=True)  # (N, 1)

    # PDE residual in normalized coords
    pde_residual = du_dt_norm + (1.0 / 1.4) * du_dxi_sum
    residual     = tf.math.square(pde_residual)
    return residual


def boundary_loss_advection_hd(model, x_boundary, alpha=0.1, T=1.0):
    """
    TF format.
    Boundary loss for high-dimensional advection equation.

    Args:
    -----
        model: PINN network
        x_boundary: tensor of shape (n_samples, d+1)
                    columns: [x1', ..., xd', t_normalized]
        alpha: Gaussian coefficient (alpha=0.1)
        T: final time

    Returns:
    --------
        residual_boundary: squared error, tensor of shape (n_samples, 1)
    """
    x_spatial_norm = x_boundary[:, :-1]    # (n_samples, d)
    t_normalized   = x_boundary[:, -1:]    # (n_samples, 1)

    # denormalize
    x_spatial  = 0.7 * x_spatial_norm + 0.5
    t_original = (t_normalized + 1.0) / 2.0 * T

    norm_sq = tf.reduce_sum(
        tf.math.square(x_spatial - t_original), axis=1, keepdims=True)
    u_exact = tf.math.exp(-(1.0 / alpha) * norm_sq)

    u_pred            = model(x_boundary)
    residual_boundary = tf.math.square(u_pred - u_exact)
    return residual_boundary


def ic_loss_advection_hd(model, x_ic, alpha=0.1):
    """
    TF format.
    IC loss for high-dimensional advection equation.
    At t=0 (t_normalized=-1): u(x,0) = exp(-1/alpha * sum(xi^2))

    Args:
    -----
        model: PINN network
        x_ic: tensor of shape (n_samples, d+1)
              columns: [x1', ..., xd', t_normalized] where t_normalized=-1
        alpha: Gaussian coefficient (alpha=0.1)

    Returns:
    --------
        residual_ic: squared error at t=0, tensor of shape (n_samples, 1)
    """
    x_spatial_norm = x_ic[:, :-1]    # (n_samples, d)

    x_spatial = 0.7 * x_spatial_norm + 0.5

    norm_sq    = tf.reduce_sum(
        tf.math.square(x_spatial), axis=1, keepdims=True)
    u_exact_ic = tf.math.exp(-(1.0 / alpha) * norm_sq)

    u_pred      = model(x_ic)
    residual_ic = tf.math.square(u_pred - u_exact_ic)
    return residual_ic