# File: plot_solution_comparison_hd_hyperbolic.py
# Author: Anshima Singh, June 2026
# Description: Plots exact solution, predicted solution, and pointwise error
#              for the high-dimensional hyperbolic problem (probsetup 23)
#              at four time levels (t = 0.00, 0.25, 0.50, 1.00).
#              Figure has three rows (exact, predicted, pointwise error)
#              and four columns (one per time level), per dimension pair.


import numpy as np
import matplotlib.pyplot as plt
import os
import argparse
import itertools
import sys

##############################################################
# ARGUMENT PARSER
##############################################################
parser = argparse.ArgumentParser(
    description='Plot 2D solution slices for high-dimensional '
                'hyperbolic problem (probsetup 23)')
parser.add_argument('--store_dir', type=str, default='./store_data',
                    help='Directory containing results')
parser.add_argument('--n_dim', type=int, default=7,
                    help='Total dimension including time (d+1). '
                         'e.g. 5 for d=4, 7 for d=6')
parser.add_argument('--n_grid', type=int, default=100,
                    help='Number of grid points per spatial dimension '
                         'for the 2D slice plot')
parser.add_argument('--n_time', type=int, default=4,
                    help='Number of time slices')
parser.add_argument('--T', type=float, default=1.0,
                    help='Final time')
parser.add_argument('--ckpt_dir', type=str, default='./pdf_ckpt',
                    help='Checkpoint directory for loading the model')
parser.add_argument('--dim_pairs', type=str, default='all',
                    help='Which dimension pairs to plot. '
                         '"all" plots all unique pairs. '
                         'Or specify as "0,1 0,2 1,2" etc.')
parser.add_argument('--alpha', type=float, default=0.1,
                    help='Gaussian coefficient alpha')


args = parser.parse_args()

n_spatial = args.n_dim - 1    # spatial dimension d
T         = args.T
n_grid    = args.n_grid
n_time    = args.n_time

##############################################################
# FIGURES DIRECTORY
##############################################################
figures_dir = os.path.join(os.path.dirname(args.store_dir), 'Figures')
os.makedirs(figures_dir, exist_ok=True)

##############################################################
# EXACT SOLUTION
# u(x,t) = exp(-1/alpha * sum(xi - t)^2)
# other dims fixed at peak location x_other = t
##############################################################
def exact_solution(X1, X2, t, dim_i, dim_j):
    x_other = t
    n_other = n_spatial - 2
    norm_sq = (X1 - t)**2 + (X2 - t)**2 + \
                n_other * (x_other - t)**2       
    return np.exp(-(1.0 / args.alpha) * norm_sq)


##############################################################
# LOAD MODEL AND PREDICT
##############################################################
def load_model_and_predict(X1_flat, X2_flat, t_val, dim_i, dim_j,
                            n_spatial, ckpt_dir):
    try:
        import tensorflow as tf
        sys.path.insert(0, os.path.dirname(os.path.dirname(
            os.path.abspath(__file__))))
        import nn_model

        # build network — must match training architecture
        n_hidden   = 64
        netu_depth = 6
        activation = 'tanh'

        net_u = nn_model.FCNN('FCNN', 1, netu_depth,
                               n_hidden, activation)

        n_pts    = X1_flat.shape[0]
        t_norm   = 2.0 * t_val / T - 1.0
        x_input  = np.zeros((n_pts, n_spatial + 1), dtype=np.float32)

        # fix other dimensions at peak location in normalized coords
        peak_norm = (t_val - 0.5) / 0.7
        x_input[:, :] = peak_norm
        x_input[:, dim_i] = ((X1_flat - 0.5) / 0.7).astype(np.float32)
        x_input[:, dim_j] = ((X2_flat - 0.5) / 0.7).astype(np.float32)
        x_input[:, -1] = t_norm

        # initialize network with a dummy forward pass
        net_u(x_input[:1, :])

        # restore checkpoint
        optimizer = tf.keras.optimizers.legacy.Adam(learning_rate=0.0001)
        ckpt      = tf.train.Checkpoint(step=tf.Variable(1),
                                         optimizer=optimizer,
                                         net=net_u)
        manager   = tf.train.CheckpointManager(ckpt, ckpt_dir,
                                                max_to_keep=5)
        if manager.latest_checkpoint:
            ckpt.restore(manager.latest_checkpoint).expect_partial()
            print(f'  Checkpoint restored: {manager.latest_checkpoint}')
        else:
            print(f'  WARNING: No checkpoint found in {ckpt_dir}')
            return None

        return net_u(x_input).numpy().flatten()

    except Exception as e:
        print(f'  ERROR loading model: {e}')
        return None


##############################################################
# DETERMINE DIMENSION PAIRS
##############################################################
if args.dim_pairs == 'all':
    pairs = list(itertools.combinations(range(n_spatial), 2))
else:
    pairs = []
    for pair_str in args.dim_pairs.strip().split():
        i, j = pair_str.split(',')
        pairs.append((int(i), int(j)))

print(f'Spatial dimension d = {n_spatial}')
pairs_display = [(i+1, j+1) for i, j in pairs]
print(f'Plotting {len(pairs)} dimension pairs: {pairs_display}')

##############################################################
# TIME LEVELS
##############################################################
t_vals = [0.0, 0.25, 0.5, 1.0]


##############################################################
# SPATIAL GRID (probsetup 23: x in [-0.2, 1.2])
##############################################################
x_grid = np.linspace(-0.2, 1.2, n_grid)
X1_2d, X2_2d = np.meshgrid(x_grid, x_grid, indexing='ij')
X1_flat = X1_2d.flatten()
X2_flat = X2_2d.flatten()

##############################################################
# LOOP OVER DIMENSION PAIRS
##############################################################
for (dim_i, dim_j) in pairs:

    print(f'\n=== Plotting x{dim_i+1} vs x{dim_j+1} ===')

    fixed_dims = [k for k in range(n_spatial)
                  if k != dim_i and k != dim_j]
    fixed_str  = ', '.join([f'$x_{k+1}=0$' for k in fixed_dims])

    u_exact_all = np.zeros((n_grid, n_grid, n_time))
    u_pred_all  = np.zeros((n_grid, n_grid, n_time))
    pred_loaded = True

    for k, t_val in enumerate(t_vals):
        # exact solution
        u_exact_all[:, :, k] = exact_solution(
            X1_2d, X2_2d, t_val, dim_i, dim_j)

        # predicted solution from checkpoint
        u_pred_flat = load_model_and_predict(
            X1_flat, X2_flat, t_val, dim_i, dim_j,
            n_spatial, args.ckpt_dir)

        if u_pred_flat is not None:
            u_pred_all[:, :, k] = u_pred_flat.reshape(n_grid, n_grid)
        else:
            pred_loaded = False

    # color scale
    vmin_sol = 0.0
    vmax_sol = np.max(u_exact_all)
    vmax_err = np.max(np.abs(u_exact_all - u_pred_all)) \
               if pred_loaded else 1.0

    # number of rows: 2 if pred loaded (exact + pred),
    #                 3 if pred loaded (exact + pred + error)
    n_rows = 3 if pred_loaded else 1

    fig, axes = plt.subplots(n_rows, n_time,
                              figsize=(4 * n_time, 4 * n_rows))
    if n_rows == 1:
        axes = axes[np.newaxis, :]

    for k, t_val in enumerate(t_vals):

        # --- row 0: exact solution ---
        im0 = axes[0, k].contourf(
            x_grid, x_grid, u_exact_all[:, :, k],
            levels=50, cmap='hot',
            vmin=vmin_sol, vmax=vmax_sol)
        axes[0, k].set_title(f'$t = {t_val:.2f}$', fontsize=12)
        axes[0, k].set_xlabel(f'$x_{dim_i+1}$', fontsize=11)
        # mark peak location
       
        peak_x = t_val
        peak_y = t_val
       
        axes[0, k].plot(peak_x, peak_y, 'k*',
                        markersize=12, markeredgewidth=1.5, zorder=5)
        plt.colorbar(im0, ax=axes[0, k])

        if pred_loaded:
            # --- row 1: predicted solution ---
            im1 = axes[1, k].contourf(
                x_grid, x_grid, u_pred_all[:, :, k],
                levels=50, cmap='hot',
                vmin=vmin_sol, vmax=vmax_sol)
            axes[1, k].set_title(f'$t = {t_val:.2f}$', fontsize=12)
            axes[1, k].set_xlabel(f'$x_{dim_i+1}$', fontsize=11)
            axes[1, k].plot(peak_x, peak_y, 'k*',
                            markersize=12, markeredgewidth=1.5, zorder=5)
            plt.colorbar(im1, ax=axes[1, k])


            # --- row 2: pointwise error ---
            err = np.abs(u_exact_all[:, :, k] - u_pred_all[:, :, k])
            im2 = axes[2, k].contourf(
                x_grid, x_grid, err,
                levels=50, cmap='Blues',
                vmin=0.0, vmax=vmax_err)
            axes[2, k].set_title(f'$t = {t_val:.2f}$', fontsize=12)
            axes[2, k].set_xlabel(f'$x_{dim_i+1}$', fontsize=11)
            plt.colorbar(im2, ax=axes[2, k])

    # row labels
    axes[0, 0].set_ylabel(
        f'Exact solution\n$x_{dim_j+1}$', fontsize=12)
    if pred_loaded:
        axes[1, 0].set_ylabel(
            f'Predicted solution\n$x_{dim_j+1}$', fontsize=12)
        axes[2, 0].set_ylabel(
            f'Pointwise Error'
            f'\n$x_{dim_j+1}$', fontsize=12)


    plt.tight_layout()

    save_path = os.path.join(
        figures_dir,
        f'prob23_slice_x{dim_i+1}_x{dim_j+1}.png')
    plt.savefig(save_path, dpi=150, bbox_inches='tight')
    plt.close()
    print(f'  Saved: {save_path}')

print('\n=== All slice plots saved ===')