# File: plot_loss_per_epoch.py
# Author: Anshima Singh, June 2026
# Description: Plots loss components as a function of training epochs.
#              Includes two plots (residual loss, PDE loss) when boundary and
#              initial condition losses are unavailable, and four plots
#              (residual loss, PDE loss, boundary loss, IC loss) when available.

import numpy as np
import matplotlib.pyplot as plt
import os
import argparse

##############################################################
# ARGUMENT PARSER
##############################################################
parser = argparse.ArgumentParser(
    description='Plot loss components per epoch')
parser.add_argument("--probsetup", type=int, default=23,
               help='The problem setup: 18, Transient Gaussian peak (alpha=100) (2D); '
                    '20, A rotating peak problem (2D); '
                    '21, A nonlinear problem (viscous Burgers’ equation) (2D); '
                    '22, A high-dimensional parabolic problem (6+1 and 8+1 D); '
                    '23, A high-dimensional hyperbolic problem (6+1 D). ')
parser.add_argument('--store_dir', type=str, default='./store_data',
                    help='Directory containing results')
parser.add_argument('--n_epochs', type=int, default=3000,
                    help='Number of epochs per stage')
parser.add_argument('--max_stage', type=int, default=5,
                    help='Number of adaptive stages')
parser.add_argument('--batch_size', type=int, default=1000,
                    help='Batch size used during training')
parser.add_argument('--n_train', type=int, default=5000,
                    help='Number of training points at initial stage')
parser.add_argument("--alpha", type=float, default=0.1,
               help='Problem-dependent coefficient: '
                    '18, Gaussian peak sharpness coefficient - default 100.0; '
                    '20, Rotating peak coefficient - default 0.01; '
                    '21, Viscosity coefficient - default 0.001; '
                    '22, Gaussian coefficient - default 10.0; '
                    '23, Gaussian coefficient - default 0.1. ')
parser.add_argument('--replace_all', type=int, default=0,
                    help='0 for DAS-G, 1 for DAS-R')
args = parser.parse_args()

##############################################################
# PROBLEM TITLES
##############################################################
problem_titles = {
    18: 'Moving Transient Gaussian Peak',
    20: 'Rotation Equation',
    21: 'Burgers Equation',
    22: 'High-Dimensional parabolic problem',
    23: 'High-Dimensional hyperbolic problem',
}
title = problem_titles.get(args.probsetup,
                            f'Problem {args.probsetup}')

##############################################################
# LOAD DATA
##############################################################
res_loss  = np.loadtxt(
    os.path.join(args.store_dir, 'residualloss_vs_iter.dat'))
pde_loss  = np.loadtxt(
    os.path.join(args.store_dir, 'pdeloss_vs_iter.dat'))
val_error = np.loadtxt(
    os.path.join(args.store_dir, 'validation_error.dat'))

total_iters = len(res_loss)

# load BD and IC loss if available
bd_loss_path = os.path.join(args.store_dir, 'bdloss_vs_iter.dat')
ic_loss_path = os.path.join(args.store_dir, 'icloss_vs_iter.dat')
has_bd_ic    = (os.path.exists(bd_loss_path) and
                os.path.exists(ic_loss_path))
if has_bd_ic:
    bd_loss = np.loadtxt(bd_loss_path)
    ic_loss = np.loadtxt(ic_loss_path)

##############################################################
# COMPUTE ITERS PER EPOCH AT EACH STAGE
# DAS-G: dataset grows each stage
##############################################################
stage_iters_per_epoch = []
stage_total_iters     = []
cumulative            = 0

for s in range(1, args.max_stage + 1):
    if args.replace_all == 1:
        iters_per_epoch = -(-(args.n_train) // args.batch_size)
    else:
        iters_per_epoch = -(-( args.n_train * s) // args.batch_size)
    stage_iters     = args.n_epochs * iters_per_epoch
    stage_iters_per_epoch.append(iters_per_epoch)
    stage_total_iters.append(stage_iters)
    cumulative += stage_iters

##############################################################
# AVERAGE LOSS PER EPOCH FOR EACH STAGE
##############################################################
def average_per_epoch(loss_array, start_iter, n_epochs, iters_per_epoch):
    """Average loss values over each epoch."""
    epoch_means = []
    for e in range(n_epochs):
        i_start = start_iter + e * iters_per_epoch
        i_end   = start_iter + (e+1) * iters_per_epoch
        if i_end <= len(loss_array):
            epoch_means.append(np.mean(loss_array[i_start:i_end]))
    return np.array(epoch_means)

# compute per-epoch averages for each stage
res_per_epoch = []
pde_per_epoch = []
bd_per_epoch  = []
ic_per_epoch  = []

cumulative   = 0
total_epochs = 0

for s in range(args.max_stage):
    iters_per_epoch = stage_iters_per_epoch[s]
    start_iter      = cumulative

    res_epoch = average_per_epoch(res_loss, start_iter,
                                   args.n_epochs, iters_per_epoch)
    pde_epoch = average_per_epoch(pde_loss, start_iter,
                                   args.n_epochs, iters_per_epoch)

    res_per_epoch.append(res_epoch)
    pde_per_epoch.append(pde_epoch)

    if has_bd_ic:
        bd_epoch = average_per_epoch(bd_loss, start_iter,
                                      args.n_epochs, iters_per_epoch)
        ic_epoch = average_per_epoch(ic_loss, start_iter,
                                      args.n_epochs, iters_per_epoch)
        bd_per_epoch.append(bd_epoch)
        ic_per_epoch.append(ic_epoch)

    total_epochs += len(res_epoch)
    cumulative   += stage_total_iters[s]

# concatenate all stages
res_all = np.concatenate(res_per_epoch)
pde_all = np.concatenate(pde_per_epoch)
epochs  = np.arange(1, len(res_all)+1)

if has_bd_ic:
    bd_all = np.concatenate(bd_per_epoch)
    ic_all = np.concatenate(ic_per_epoch)

print(f'=== Problem {args.probsetup}: {title} ===')
print(f'Total epochs  : {len(res_all)}')
print(f'Residual first: {res_all[0]:.4e}  last: {res_all[-1]:.4e}  '
      f'min: {np.min(res_all):.4e}')
print(f'PDE loss first: {pde_all[0]:.4e}  last: {pde_all[-1]:.4e}  '
      f'min: {np.min(pde_all):.4e}')
if has_bd_ic:
    print(f'BD loss  first: {bd_all[0]:.4e}  last: {bd_all[-1]:.4e}  '
          f'min: {np.min(bd_all):.4e}')
    print(f'IC loss  first: {ic_all[0]:.4e}  last: {ic_all[-1]:.4e}  '
          f'min: {np.min(ic_all):.4e}')

##############################################################
# STAGE BOUNDARY EPOCH INDICES
##############################################################
stage_boundary_epochs = []
cumulative_epochs     = 0
for s in range(args.max_stage - 1):
    cumulative_epochs += len(res_per_epoch[s])
    stage_boundary_epochs.append(cumulative_epochs)

stage_colors = ['gray', 'green', 'orange', 'purple']

def add_stage_lines_epoch(ax):
    for i, sb in enumerate(stage_boundary_epochs):
        ax.axvline(x=sb,
                   color=stage_colors[i % len(stage_colors)],
                   linestyle='--', linewidth=1.5, alpha=0.7,
                   label=f'Adaptive stage {i+1} start')

##############################################################
# PLOT
##############################################################
if has_bd_ic:
    fig, axes = plt.subplots(2, 2, figsize=(14, 10))
    axes = axes.flatten()
else:
    fig, axes = plt.subplots(1, 2, figsize=(14, 5))

# --- Residual loss per epoch ---
axes[0].semilogy(epochs, res_all, 'b-',
                 linewidth=1.5, label='Residual loss')
add_stage_lines_epoch(axes[0])
axes[0].set_xlabel('Epoch', fontsize=12)
axes[0].set_ylabel('Mean Residual Loss', fontsize=12)
axes[0].set_title(f'Residual Loss per Epoch',
                  fontsize=11)
axes[0].legend(fontsize=10)
axes[0].grid(True, alpha=0.3)
axes[0].set_xlim([1, len(res_all)])

# --- PDE loss per epoch ---
axes[1].semilogy(epochs, pde_all, 'r-',
                 linewidth=1.5, label='PDE loss')
add_stage_lines_epoch(axes[1])
axes[1].set_xlabel('Epoch', fontsize=12)
axes[1].set_ylabel('Mean PDE Loss', fontsize=12)
axes[1].set_title(f'PDE Loss per Epoch',
                  fontsize=11)
axes[1].legend(fontsize=10)
axes[1].grid(True, alpha=0.3)
axes[1].set_xlim([1, len(pde_all)])

if has_bd_ic:
    # --- Boundary loss per epoch ---
    if np.any(np.array(bd_all) > 0):
        axes[2].semilogy(epochs, bd_all, 'g-',
                         linewidth=1.5, label='Boundary loss')
    else:
        axes[2].plot(epochs, bd_all, 'g-',
                     linewidth=1.5, label='Boundary loss')
    add_stage_lines_epoch(axes[2])
    axes[2].set_xlabel('Epoch', fontsize=12)
    axes[2].set_ylabel('Mean Boundary Loss', fontsize=12)
    axes[2].set_title(f'Boundary Loss per Epoch',
                      fontsize=11)
    axes[2].legend(fontsize=10)
    axes[2].grid(True, alpha=0.3)
    axes[2].set_xlim([1, len(bd_all)])

    # --- IC loss per epoch ---
    if np.any(np.array(ic_all) > 0):
        axes[3].semilogy(epochs, ic_all, 'm-',
                         linewidth=1.5, label='IC loss')
    else:
        axes[3].plot(epochs, ic_all, 'm-',
                     linewidth=1.5, label='IC loss')
    add_stage_lines_epoch(axes[3])
    axes[3].set_xlabel('Epoch', fontsize=12)
    axes[3].set_ylabel('Mean IC Loss', fontsize=12)
    axes[3].set_title(f'IC Loss per Epoch',
                      fontsize=11)
    axes[3].legend(fontsize=10)
    axes[3].grid(True, alpha=0.3)
    axes[3].set_xlim([1, len(ic_all)])

plt.tight_layout()
figures_dir = os.path.join(os.path.dirname(args.store_dir), 'Figures')
os.makedirs(figures_dir, exist_ok=True)
save_path = os.path.join(figures_dir,
    f'prob{args.probsetup}_loss_per_epoch.png')
plt.savefig(save_path, dpi=150, bbox_inches='tight')
plt.close()
print(f'Plot saved to {save_path}')