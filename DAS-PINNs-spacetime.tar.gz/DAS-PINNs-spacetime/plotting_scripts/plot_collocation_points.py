# File: plot_collocation_points.py
# Author: Anshima Singh, June 2026
# Description: Plots spatial collocation points and histogram of temporal points
#              at each adaptive stage
#              Includes four figures: spatial collocation points (separate),
#              spatial collocation points (accumulated), temporal histogram (separate),
#              temporal histogram (accumulated).


import numpy as np
import matplotlib.pyplot as plt
import math
import os
import argparse

parser = argparse.ArgumentParser(
    description='Plot collocation points at each adaptive stage')
parser.add_argument("--probsetup", type=int, default=18,
                    help='The problem setup: 18, Transient Gaussian peak (alpha=100) (2D); '
                    '20, A rotating peak problem (2D); '
                    '21, A nonlinear problem (viscous Burgers’ equation) (2D); '
                    '22, A high-dimensional parabolic problem (6+1 and 8+1 D); '
                    '23, A high-dimensional hyperbolic problem (6+1 D). ')
parser.add_argument('--store_dir', type=str, default='./store_data')
parser.add_argument('--max_stage', type=int, default=5)
parser.add_argument('--n_train', type=int, default=2000)
parser.add_argument('--T', type=float, default=1.0)
parser.add_argument('--n_bins', type=int, default=20)
parser.add_argument("--alpha", type=float, default=100.0,
                    help='Problem-dependent coefficient: '
                    '18, Gaussian peak sharpness coefficient - default 100.0; '
                    '20, Rotating peak coefficient - default 0.01; '
                    '21, Viscosity coefficient - default 0.001; '
                    '22, Gaussian coefficient - default 10.0; '
                    '23, Gaussian coefficient - default 0.1. ')
parser.add_argument('--dim1', type=int, default=0,
                    help='First spatial dimension index to plot')
parser.add_argument('--dim2', type=int, default=1,
                    help='Second spatial dimension index to plot')
parser.add_argument('--replace_all', type=int, default=0,
                    help='0 for DAS-G, 1 for DAS-R')
args = parser.parse_args()

# PEAK INFO
peak_info = {
    18: [],   # moving peak — no fixed marker
    20: [],   # rotating peak — no fixed marker
    21: [],   # moving front — no peak marker
    22: [{'c': 0.0, 'x0': 0.0, 'y0': 0.0}],
    23: [],    # moving peak — no fixed marker
}
peaks = peak_info.get(args.probsetup, [])

# LOAD INITIAL POINTS
initial_fname = os.path.join(args.store_dir, 'stage_0_interior.dat')
if os.path.exists(initial_fname):
    x_initial = np.loadtxt(initial_fname)
    print(f'Initial points loaded: {x_initial.shape[0]}')
else:
    raise FileNotFoundError(f'Initial points not found: {initial_fname}')

# LOAD RESAMPLED POINTS
resampled = {}
for s in range(1, args.max_stage):
    fname = os.path.join(args.store_dir,
                         f'stage_{s}_resample_interior.dat')
    if os.path.exists(fname):
        resampled[s] = np.loadtxt(fname)
        print(f'Stage {s} resample: {resampled[s].shape[0]} points')
    else:
        print(f'Stage {s} resample: file not found — {fname}')

# BUILD CUMULATIVE AND SEPARATE POINT SETS
cumulative_points = {1: x_initial}
x_cumulative = x_initial.copy()
for s in range(1, args.max_stage):
    if s in resampled:
        x_cumulative = np.concatenate(
            (x_cumulative, resampled[s]), axis=0)
        cumulative_points[s+1] = x_cumulative.copy()
        print(f'Stage {s+1} cumulative: {x_cumulative.shape[0]} points')

separate_points = {1: x_initial}
for s in range(1, args.max_stage):
    if s in resampled:
        separate_points[s+1] = resampled[s]

# COLORS AND LABELS
stage_colors = {1: 'gray', 2: 'blue', 3: 'green',
                4: 'red',  5: 'magenta', 6: 'purple',
                7: 'brown', 8: 'pink', 9: 'cyan', 10: 'orange'}

if args.replace_all == 1:
    stage_labels = {s: (f'Initial stage\n(uniform, {args.n_train} pts)'
                        if s == 1
                        else f'Adaptive stage {s-1}\n({args.n_train} pts)')
                    for s in range(1, 11)}
else:
    stage_labels = {s: (f'Initial stage\n(uniform, {args.n_train} pts)'
                        if s == 1
                        else f'Adaptive stage {s-1}\n({args.n_train*s} pts)')
                    for s in range(1, 11)}

sep_labels = {s: (f'Initial stage\n(uniform, {args.n_train} pts)'
                  if s == 1
                  else f'Adaptive stage {s-1}\n({args.n_train} pts)')
              for s in range(1, 11)}

# FIGURES DIRECTORY
figures_dir = os.path.join(os.path.dirname(args.store_dir), 'Figures', 'Collocation_Points')
os.makedirs(figures_dir, exist_ok=True)

# GRID LAYOUT HELPER
def make_grid_axes(n_panels, panel_size=5):
    """
    Create a grid of axes with max 3 columns.
    Returns fig, axes as flat list.
    """
    n_cols = min(3, n_panels)
    n_rows = math.ceil(n_panels / n_cols)
    fig, axes = plt.subplots(n_rows, n_cols,
                             figsize=(panel_size * n_cols,
                                      panel_size * n_rows))
    axes_flat = np.array(axes).flatten()
    for idx in range(n_panels, len(axes_flat)):
        axes_flat[idx].set_visible(False)
    return fig, axes_flat

def plot_spatial(points_dict, labels_dict, fname_suffix):
    """Plot spatial distribution (x1 vs x2) in grid layout."""
    n_panels = len(points_dict)
    fig, axes_flat = make_grid_axes(n_panels)

    for idx, (s, pts) in enumerate(points_dict.items()):
        ax    = axes_flat[idx]
        x1 = pts[:, args.dim1]
        x2 = pts[:, args.dim2]  
        color = stage_colors.get(s, 'blue')

        ax.scatter(x1, x2, c=color, s=1,
                   alpha=0.3, rasterized=True)

        # mark fixed peak locations
        for pp in peaks:
            ax.plot(pp['x0'], pp['y0'], 'k*',
                    markersize=10, markeredgewidth=2, zorder=5)

        # for rotation problem — draw circular peak path
        if args.probsetup == 20:
            theta = np.linspace(0, 1.0, 200)
            ax.plot(np.cos(theta), np.sin(theta),
                    'k--', linewidth=1.5, alpha=0.7)

        ax.set_xlim([-1, 1])
        ax.set_ylim([-1, 1])
        ax.set_xlabel(f'$x_{{{args.dim1+1}}}$', fontsize=12)
        ax.set_ylabel(f'$x_{{{args.dim2+1}}}$', fontsize=12)
        ax.set_title(labels_dict.get(s, f'Stage {s}'), fontsize=11)
        ax.set_aspect('equal')
        ax.grid(True, alpha=0.3)

    plt.tight_layout()
    save_path = os.path.join(figures_dir,
        f'prob{args.probsetup}_{fname_suffix}.png')
    plt.savefig(save_path, dpi=150, bbox_inches='tight')
    plt.close()
    print(f'Saved: {save_path}')

def plot_temporal(points_dict, labels_dict, fname_suffix):
    """Plot temporal histogram in grid layout."""
    n_panels = len(points_dict)
    fig, axes_flat = make_grid_axes(n_panels)

    t_bins_normalized  = np.linspace(-1.0, 1.0, args.n_bins + 1)
    t_bins_original    = (t_bins_normalized + 1.0) / 2.0 * args.T
    t_centers_original = (t_bins_original[:-1] + t_bins_original[1:]) / 2.0
    bin_width          = (args.T / args.n_bins) * 0.8

    for idx, (s, pts) in enumerate(points_dict.items()):
        ax           = axes_flat[idx]
        t_normalized = pts[:, -1]
        color        = stage_colors.get(s, 'blue')

        counts, _ = np.histogram(t_normalized, bins=t_bins_normalized)

        ax.bar(t_centers_original, counts,
               width=bin_width, color=color,
               alpha=0.7, edgecolor='black', linewidth=0.5)

        ax.set_xlabel('$t$', fontsize=12)
        ax.set_ylabel('Number of points', fontsize=12)
        ax.set_title(labels_dict.get(s, f'Stage {s}'), fontsize=11)
        ax.grid(True, alpha=0.3, axis='y')
        ax.set_xlim([0, args.T])

        print(f'\n=== Stage {s} ({fname_suffix}) ===')
        print(f'Total points     : {pts.shape[0]}')
        print(f'Near t=0  (t<0.1): '
              f'{np.sum((t_normalized+1)/2*args.T < 0.1)}')
        print(f'Near t=T  (t>0.9): '
              f'{np.sum((t_normalized+1)/2*args.T > 0.9)}')
        print(f'Mean t           : '
              f'{np.mean((t_normalized+1)/2*args.T):.3f}')

    plt.tight_layout()
    save_path = os.path.join(figures_dir,
        f'prob{args.probsetup}_{fname_suffix}.png')
    plt.savefig(save_path, dpi=150, bbox_inches='tight')
    plt.close()
    print(f'Saved: {save_path}')

# GENERATE ALL FOUR FIGURES
plot_spatial(cumulative_points, stage_labels,
             'collocation_spatial')
plot_spatial(separate_points, sep_labels,
             'collocation_separate')
plot_temporal(cumulative_points, stage_labels,
              'collocation_temporal')
plot_temporal(separate_points, sep_labels,
              'collocation_temporal_separate')

print('=== All collocation point plots saved ===')