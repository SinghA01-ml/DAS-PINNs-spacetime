# File: plot_solution_comparison_and_error_2D_problems.py
# Author: Anshima Singh, June 2026
# Description: Plots exact solution, predicted solution, and pointwise error
#              for two-dimensional problems (probsetup: 18,20, and 21)
#              at four time levels (t = 0.00, 0.25, 0.50, 1.00).
#              Figure has three rows (exact, predicted, pointwise error)
#              and four columns (one per time level).


import numpy as np
import matplotlib.pyplot as plt
import os
import argparse

##############################################################
# ARGUMENT PARSER
##############################################################
parser = argparse.ArgumentParser(
    description='Plot solution comparison')
parser.add_argument("--probsetup", type=int, default=18,
                    help='The problem setup: 18, Transient Gaussian peak (alpha=100) (2D); '
                    '20, A rotating peak problem (2D). ')
parser.add_argument('--store_dir', type=str, default='./store_data',
                    help='Directory containing results')
parser.add_argument('--n_spatial', type=int, default=256,
                    help='Number of spatial points per dimension')
parser.add_argument('--n_per_dim', type=int, default=50,
                    help='Number of points per dim for different problems')
parser.add_argument('--n_time', type=int, default=5,
                    help='Number of time slices')
parser.add_argument('--T', type=float, default=1.0,
                    help='Final time')
parser.add_argument('--n_dim', type=int, default=3,
                    help='Total dimension including time')
parser.add_argument("--alpha", type=float, default=100.0,
                    help='Problem-dependent coefficient: '
                    '18, Gaussian peak sharpness coefficient - default 100.0; '
                    '20, Rotating peak coefficient - default 0.01. ')
args = parser.parse_args()

##############################################################
# PROBLEM-SPECIFIC INFO
##############################################################
problem_titles = {
    18: 'Moving Transient Gaussian Peak',
    20: 'Rotation Equation',

}

title = problem_titles.get(args.probsetup,
                            f'Problem {args.probsetup}')

# peak parameters for marker plotting
peak_info = {
    18: [],   # peak is moving linearly - handled separately
    20: [],   # peak path is circular - handled separately
}
peak_params = peak_info.get(args.probsetup, [])

# n_spatial for each problem
if args.probsetup == 18:
    if args.alpha <= 10:
        n_spatial = 50
    elif args.alpha <= 100:
        n_spatial = 100
    elif args.alpha <= 500:
        n_spatial = 200
    else:
        n_spatial = 256
elif args.probsetup == 20:
    if args.alpha <= 0.05:
        n_spatial = 200
    elif args.alpha <= 0.1:
        n_spatial = 100
    else:
        n_spatial = 50
else:
    n_spatial = args.n_spatial

n_time = args.n_time
T      = args.T

##############################################################
# LOAD DATA
##############################################################
u_pred = np.loadtxt(
    os.path.join(args.store_dir, 'u_pred.dat')).reshape(-1, 1)
u_true = np.loadtxt(
    os.path.join(args.store_dir, 'u_true.dat')).reshape(-1, 1)

print(f'=== Problem {args.probsetup}: {title} ===')
print(f'u_true max : {np.max(u_true):.6f}')
print(f'u_true min : {np.min(u_true):.6f}')
print(f'u_pred max : {np.max(u_pred):.6f}')
print(f'u_pred min : {np.min(u_pred):.6f}')
print(f'MSE        : {np.mean((u_true - u_pred)**2):.6e}')
print(f'Max error  : {np.max(np.abs(u_true - u_pred)):.6e}')

##############################################################
# RESHAPE
##############################################################
n_time_data = args.n_time  # 5 (actual data size)
u_true_grid = u_true.reshape(n_spatial, n_spatial, n_time_data)
u_pred_grid = u_pred.reshape(n_spatial, n_spatial, n_time_data)


# drop t=0.75 (index 3), keep [0, 0.25, 0.5, 1.0]
keep_idx    = [0, 1, 2, 4]
u_true_grid = u_true_grid[:, :, keep_idx]
u_pred_grid = u_pred_grid[:, :, keep_idx]
err_grid    = np.abs(u_true_grid - u_pred_grid)

x1     = np.linspace(-1.0, 1.0, n_spatial)
x2     = np.linspace(-1.0, 1.0, n_spatial)
t_vals = [0.0, 0.25, 0.5, 1.0]
n_time = 4  # update for plotting loop

vmin_sol = 0.0
vmax_sol = max(np.max(u_true_grid), np.max(u_pred_grid))
vmax_err = np.max(err_grid)

##############################################################
# FIGURE — 3 rows x n_time columns
##############################################################
fig, axes = plt.subplots(3, n_time,
                         figsize=(4*n_time, 10))

for k in range(n_time):

    # --- row 1: u_exact ---
    im1 = axes[0, k].contourf(x1, x2,
                               u_true_grid[:, :, k],
                               levels=50, cmap='hot',
                               vmin=vmin_sol, vmax=vmax_sol)
    axes[0, k].set_title(f'$t = {t_vals[k]:.2f}$', fontsize=12)
    axes[0, k].set_xlabel('$x_1$', fontsize=10)
    plt.colorbar(im1, ax=axes[0, k])


    if args.probsetup == 18:
        for row_ax in [axes[0, k], axes[1, k]]:
            xp = -0.5 + 0.5 * t_vals[k]  
            yp = 0.0
            row_ax.plot(xp, yp, 'm*', markersize=6, markeredgewidth=0.4,
                        zorder=5,
                        label='Peak' if (row_ax is axes[0, k] and k == 0) else '')
    # for rotation problem - draw circular peak path and mark peak center
    if args.probsetup == 20:
        theta = np.linspace(0, 1.0, 200)
        axes[0, k].plot(np.cos(theta), np.sin(theta),
                        'w--', linewidth=1.5, alpha=0.7,
                        label='Peak path' if k == 0 else '')
        axes[0, k].plot(np.cos(t_vals[k]), np.sin(t_vals[k]),
                        'k*', markersize=5, zorder=5)
        axes[1, k].plot(np.cos(theta), np.sin(theta),
                        'w--', linewidth=1.5, alpha=0.7)
        axes[1, k].plot(np.cos(t_vals[k]), np.sin(t_vals[k]),
                        'k*', markersize=5, zorder=5)
        

    # --- row 2: u_pred ---
    im2 = axes[1, k].contourf(x1, x2,
                               u_pred_grid[:, :, k],
                               levels=50, cmap='hot',
                               vmin=vmin_sol, vmax=vmax_sol)
    axes[1, k].set_title(f'$t = {t_vals[k]:.2f}$', fontsize=12)
    axes[1, k].set_xlabel('$x_1$', fontsize=10)
    plt.colorbar(im2, ax=axes[1, k])

    # --- row 3: absolute error ---
    im3 = axes[2, k].contourf(x1, x2,
                               err_grid[:, :, k],
                               levels=50, cmap='Blues',
                               vmin=0.0, vmax=vmax_err)
    axes[2, k].set_title(f'$t = {t_vals[k]:.2f}$', fontsize=12)
    axes[2, k].set_xlabel('$x_1$', fontsize=10)
    plt.colorbar(im3, ax=axes[2, k])



axes[0, 0].set_ylabel('Exact solution\n$x_2$', fontsize=12)
axes[1, 0].set_ylabel('Predicted solution\n$x_2$', fontsize=12)
axes[2, 0].set_ylabel('Pointwise Error\n$x_2$', fontsize=12)

# legend for multiple peaks
if len(peak_params) > 1:
    axes[0, 0].legend(fontsize=9, loc='upper left')



plt.tight_layout()
figures_dir = os.path.join(os.path.dirname(args.store_dir), 'Figures')
os.makedirs(figures_dir, exist_ok=True)

save_path = os.path.join(
    figures_dir,
    f'prob{args.probsetup}_solution_comparison.png')
plt.savefig(save_path, dpi=150, bbox_inches='tight')
plt.close()
print(f'Plot saved to {save_path}')
