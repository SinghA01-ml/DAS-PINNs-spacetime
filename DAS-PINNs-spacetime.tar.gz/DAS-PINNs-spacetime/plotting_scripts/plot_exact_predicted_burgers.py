# File: plot_exact_predicted_burgers.py
# Author: Anshima Singh, June 2026
# Description: Plots exact and predicted solutions as 3D surface plots
#              (two spatial dimensions x1, x2 and solution value as height)
#              at five time levels (t = 0.00, 0.25, 0.50, 0.75, 1.00)
#              for the 2D viscous Burgers' equation.
#              Includes two separate figures: one for exact solution,
#              one for predicted solution.

import numpy as np
import matplotlib.pyplot as plt
import math
import os
import argparse

parser = argparse.ArgumentParser()
parser.add_argument("--probsetup", type=int, default=21,
               help='The problem setup: 21, A nonlinear problem (viscous Burgers’ equation) (2D). ')
parser.add_argument('--store_dir', type=str, default='../store_data')
parser.add_argument("--alpha", type=float, default=0.001,
                    help='Viscosity coefficient - default 0.001. ')
parser.add_argument('--n_time', type=int, default=5)
parser.add_argument('--T', type=float, default=1.0)


args = parser.parse_args()

n_spatial = 200
n_time    = args.n_time
T         = args.T
alpha     = args.alpha

# load data
u_pred = np.loadtxt(
    os.path.join(args.store_dir, 'u_pred.dat')).reshape(-1, 1)
u_true = np.loadtxt(
    os.path.join(args.store_dir, 'u_true.dat')).reshape(-1, 1)

# reshape
u_true_grid = u_true.reshape(n_spatial, n_spatial, n_time)
u_pred_grid = u_pred.reshape(n_spatial, n_spatial, n_time)

x1     = np.linspace(-1.0, 1.0, n_spatial)
x2     = np.linspace(-1.0, 1.0, n_spatial)
t_vals = np.linspace(0.0, T, n_time)

X1, X2 = np.meshgrid(x1, x2)

# grid layout - max 3 columns
n_cols = min(3, n_time)
n_rows = math.ceil(n_time / n_cols)

figures_dir = os.path.join(os.path.dirname(args.store_dir), 'Figures')
os.makedirs(figures_dir, exist_ok=True)

##############################################################
# FIGURE 1 — Exact solution 3D surface
##############################################################
fig1 = plt.figure(figsize=(6*n_cols, 6*n_rows))

for k in range(n_time):
    ax = fig1.add_subplot(n_rows, n_cols, k+1,
                           projection='3d')

    Z = u_true_grid[:, :, k]

    surf = ax.plot_surface(X1, X2, Z,
                           cmap='cividis',
                           linewidth=0.5,
                           antialiased=True,
                           alpha=0.95)

    ax.set_xlim([-1, 1])
    ax.set_ylim([-1, 1])
    ax.set_zlim([0, 1])
    ax.set_xlabel('$x_1$', fontsize=15, labelpad=10)
    ax.set_ylabel('$x_2$', fontsize=15, labelpad=10)
    ax.set_zlabel('Exact solution', fontsize=15, labelpad=15)
    ax.set_title(f'$t = {t_vals[k]:.2f}$', fontsize=15)
    ax.view_init(elev=25, azim=-60)

    # reduce number of ticks
    ax.set_xticks([-1, -0.5, 0, 0.5, 1])
    ax.set_yticks([-1, -0.5, 0, 0.5, 1])
    ax.set_zticks([0, 0.2, 0.4, 0.6, 0.8, 1.0])
    ax.tick_params(axis='both', which='major', pad=3, labelsize=8)

plt.tight_layout()
save_path = os.path.join(figures_dir,
    f'prob{args.probsetup}_solution_3d_exact.png')
plt.savefig(save_path, dpi=150, bbox_inches='tight')
plt.close()
print(f'Figure 1 saved: {save_path}')

##############################################################
# FIGURE 2 — Predicted solution 3D surface
##############################################################
fig2 = plt.figure(figsize=(5*n_cols, 5*n_rows))

for k in range(n_time):
    ax = fig2.add_subplot(n_rows, n_cols, k+1,
                           projection='3d')

    Z = u_pred_grid[:, :, k]

    surf = ax.plot_surface(X1, X2, Z,
                           cmap='cividis',
                           linewidth=0.5,
                           antialiased=True,
                           alpha=0.95)

    ax.set_xlim([-1, 1])
    ax.set_ylim([-1, 1])
    ax.set_zlim([0, 1])
    ax.set_xlabel('$x_1$', fontsize=15, labelpad=10)
    ax.set_ylabel('$x_2$', fontsize=15, labelpad=10)
    ax.set_zlabel('Predicted solution', fontsize=14, labelpad=15)
    ax.set_title(f'$t = {t_vals[k]:.2f}$', fontsize=14)
    ax.view_init(elev=25, azim=-60)

    # reduce number of ticks
    ax.set_xticks([-1, -0.5, 0, 0.5, 1])
    ax.set_yticks([-1, -0.5, 0, 0.5, 1])
    ax.set_zticks([0, 0.2, 0.4, 0.6, 0.8, 1.0])
    ax.tick_params(axis='both', which='major', pad=3, labelsize=8)

plt.tight_layout()
save_path = os.path.join(figures_dir,
    f'prob{args.probsetup}_solution_3d_pred.png')
plt.savefig(save_path, dpi=150, bbox_inches='tight')
plt.close()
print(f'Figure 2 saved: {save_path}')

print(f'Max error: {np.max(np.abs(u_true_grid - u_pred_grid)):.4e}')
print(f'Rel L2:    {np.sqrt(np.sum((u_true_grid-u_pred_grid)**2)) / np.sqrt(np.sum(u_true_grid**2)):.4e}')