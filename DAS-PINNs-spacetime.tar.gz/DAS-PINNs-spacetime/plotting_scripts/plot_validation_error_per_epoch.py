# File: plot_validation_error_per_epoch.py
# Author: Anshima Singh, June 2026
# Description: Plots validation error metrics as a function of training epochs
#              for time-dependent PDE problems.
#              Includes three plots: Mean Squared Error (MSE),
#              Relative L2 Error, and Maximum Absolute Error.


import numpy as np
import matplotlib.pyplot as plt
import os
import argparse

parser = argparse.ArgumentParser(
    description='Plot validation error per epoch')
parser.add_argument("--probsetup", type=int, default=18,
                    help='The problem setup: 18, Transient Gaussian peak (alpha=100) (2D); '
                    '20, A rotating peak problem (2D); '
                    '21, A nonlinear problem (viscous Burgers’ equation) (2D); '
                    '22, A high-dimensional parabolic problem (6+1 and 8+1 D); '
                    '23, A high-dimensional hyperbolic problem (6+1 D). ')
parser.add_argument('--store_dir', type=str, default='./store_data')
parser.add_argument('--n_epochs', type=int, default=3000)
parser.add_argument('--max_stage', type=int, default=5)
parser.add_argument('--batch_size', type=int, default=500)
parser.add_argument('--n_train', type=int, default=2000)
parser.add_argument("--alpha", type=float, default=100.0,
                    help='Problem-dependent coefficient: '
                    '18, Gaussian peak sharpness coefficient - default 100.0; '
                    '20, Rotating peak coefficient - default 0.01; '
                    '21, Viscosity coefficient - default 0.001; '
                    '22, Gaussian coefficient - default 10.0; '
                    '23, Gaussian coefficient - default 0.1. ')
parser.add_argument('--replace_all', type=int, default=0,
                    help='0 for DAS-G, 1 for DAS-R')
args = parser.parse_args()

problem_titles = {
    18: 'Moving Transient Gaussian Peak',
    20: 'Rotation Equation',
    21: 'Burgers Equation',
    22: 'High-Dimensional parabolic problem',
    23: 'High-Dimensional hyperbolic problem',

}
title = problem_titles.get(args.probsetup, f'Problem {args.probsetup}')

# load all three metrics
val_error = np.loadtxt(os.path.join(args.store_dir, 'validation_error.dat'))
total_iters = len(val_error)

rel_l2_path = os.path.join(args.store_dir, 'rel_l2_vs_iter.dat')
linf_path   = os.path.join(args.store_dir, 'linf_vs_iter.dat')
has_rel_l2  = os.path.exists(rel_l2_path)
has_linf    = os.path.exists(linf_path)

if has_rel_l2:
    rel_l2 = np.loadtxt(rel_l2_path)
if has_linf:
    l_inf = np.loadtxt(linf_path)

# compute stage iters
stage_iters_per_epoch = []
stage_total_iters     = []
cumulative            = 0
for s in range(1, args.max_stage + 1):
    if args.replace_all == 1:
        iters_per_epoch = -(-(args.n_train) // args.batch_size)
    else:
        iters_per_epoch = -(-( args.n_train * s) // args.batch_size)
    stage_iters     = args.n_epochs * iters_per_epoch
    stage_iters_per_epoch.append(iters_per_epoch)
    stage_total_iters.append(stage_iters)
    cumulative += stage_iters

def average_per_epoch(loss_array, start_iter, n_epochs, iters_per_epoch):
    epoch_means = []
    for e in range(n_epochs):
        i_start = start_iter + e * iters_per_epoch
        i_end   = start_iter + (e+1) * iters_per_epoch
        if i_end <= len(loss_array):
            epoch_means.append(np.mean(loss_array[i_start:i_end]))
    return np.array(epoch_means)

def compute_per_epoch(loss_array):
    per_epoch    = []
    cumulative   = 0
    total_epochs = 0
    stage_data   = []
    for s in range(args.max_stage):
        iters_per_epoch = stage_iters_per_epoch[s]
        start_iter      = cumulative
        epoch_vals = average_per_epoch(loss_array, start_iter,
                                       args.n_epochs, iters_per_epoch)
        per_epoch.append(epoch_vals)
        stage_data.append({
            'stage'      : s+1,
            'start_epoch': total_epochs,
            'end_epoch'  : total_epochs + len(epoch_vals),
            'data'       : epoch_vals,
            'min_val'    : np.min(epoch_vals) if len(epoch_vals) > 0 else np.nan,
            'min_epoch'  : total_epochs + np.argmin(epoch_vals) + 1
                           if len(epoch_vals) > 0 else 0,
        })
        total_epochs += len(epoch_vals)
        cumulative   += stage_total_iters[s]
    return np.concatenate(per_epoch), stage_data

# compute per-epoch for all three metrics
val_all, stage_data_mse = compute_per_epoch(val_error)
if has_rel_l2:
    rl2_all, stage_data_rl2 = compute_per_epoch(rel_l2)
if has_linf:
    inf_all, stage_data_inf = compute_per_epoch(l_inf)

epochs = np.arange(1, len(val_all)+1)

# stage boundaries in epoch space
stage_boundary_epochs = []
cumulative_epochs     = 0
for s in range(args.max_stage - 1):
    cumulative_epochs += len(stage_data_mse[s]['data'])
    stage_boundary_epochs.append(cumulative_epochs)

stage_colors  = ['gray', 'green', 'orange', 'purple']
marker_colors = ['red', 'green', 'orange', 'purple', 'brown']


def add_stage_lines_epoch(ax):
    for i, sb in enumerate(stage_boundary_epochs):
        ax.axvline(x=sb, color=stage_colors[i % len(stage_colors)],
                   linestyle='--', linewidth=1.5, alpha=0.7,
                   label=f'Adaptive stage {i+1} start')

# figure
n_plots = 1 + int(has_rel_l2) + int(has_linf)
fig, axes = plt.subplots(1, n_plots, figsize=(6*n_plots, 6))
if n_plots == 1:
    axes = [axes]


# --- subplot 1: MSE per epoch ---
ax = axes[0]
ax.semilogy(epochs, val_all, 'b-', linewidth=1.5, label='Mean square error')
add_stage_lines_epoch(ax)
ax.set_xlabel('Epoch', fontsize=12)
ax.set_ylabel(r"$\mathcal{E}_{\mathrm{mse}}$")
ax.legend(fontsize=8, loc='upper right')
ax.grid(True, alpha=0.3)
ax.set_xlim([1, len(val_all)])

# --- subplot 2: Rel L2 per epoch ---
if has_rel_l2:
    ax = axes[1]
    ax.semilogy(epochs, rl2_all, 'r-', linewidth=1.5, label=r"Relative $L_2$ error")
    add_stage_lines_epoch(ax)
    ax.set_xlabel('Epoch', fontsize=12)
    ax.set_ylabel(r"$\mathcal{E}_2$")
    ax.legend(fontsize=8, loc='upper right')
    ax.grid(True, alpha=0.3)
    ax.set_xlim([1, len(rl2_all)])

# --- subplot 3: L_inf per epoch ---
if has_linf:
    ax = axes[2] if has_rel_l2 else axes[1]
    ax.semilogy(epochs, inf_all, 'g-', linewidth=1.5, label=r"$L_{\infty}$ error")
    add_stage_lines_epoch(ax)
    ax.set_xlabel('Epoch', fontsize=12)
    ax.set_ylabel(r"$\mathcal{E}_\infty$")    
    ax.legend(fontsize=8, loc='upper right')
    ax.grid(True, alpha=0.3)
    ax.set_xlim([1, len(inf_all)])

plt.tight_layout()
figures_dir = os.path.join(os.path.dirname(args.store_dir), 'Figures')
os.makedirs(figures_dir, exist_ok=True)
save_path = os.path.join(figures_dir,
    f'prob{args.probsetup}_validation_per_epoch.png')
plt.savefig(save_path, dpi=150, bbox_inches='tight')
plt.close()
print(f'Plot saved to {save_path}')

# print summary
print(f'\n=== {title} (α={args.alpha}) ===')
print(f'MSE   — min: {np.min(val_all):.4e} at epoch {np.argmin(val_all)+1}')
if has_rel_l2:
    print(f'Rel L2 — min: {np.min(rl2_all):.4e} at epoch {np.argmin(rl2_all)+1}')
if has_linf:
    print(f'$L^\\infty$ Error    — min: {np.min(inf_all):.4e} at epoch {np.argmin(inf_all)+1}')
print()
print(f'{"Stage":>6} {"MSE min":>12} {"Rel L2 min":>12} {"Linf min":>12}')
print('-'*45)
for s in range(args.max_stage):
    mse_min = f'{stage_data_mse[s]["min_val"]:.4e}'
    rl2_min = f'{stage_data_rl2[s]["min_val"]:.4e}' if has_rel_l2 else 'N/A'
    inf_min = f'{stage_data_inf[s]["min_val"]:.4e}' if has_linf else 'N/A'
    print(f'{s+1:>6} {mse_min:>12} {rl2_min:>12} {inf_min:>12}')