# File: plot_pointwise_error_burgers.py
# Author: Anshima Singh, June 2026
# Description: Plots pointwise error as 3D surface plots
#              (two spatial dimensions x1, x2 and error value as height)
#              at five time levels (t = 0.00, 0.25, 0.50, 0.75, 1.00)
#              for the 2D viscous Burgers' equation.


import numpy as np
import matplotlib.pyplot as plt
import math
import os
import argparse
from matplotlib.colors import LogNorm


parser = argparse.ArgumentParser()
parser.add_argument("--probsetup", type=int, default=21,
               help='The problem setup: 21, A nonlinear problem (viscous Burgers’ equation) (2D). ')
parser.add_argument("--alpha", type=float, default=0.001,
                    help='Viscosity coefficient - default 0.001. ')
parser.add_argument('--store_dir', type=str, default='../store_data')
parser.add_argument('--n_time', type=int, default=5)
parser.add_argument('--T', type=float, default=1.0)
args = parser.parse_args()

n_spatial = 200
n_time = args.n_time
T      = args.T

# load data
u_pred = np.loadtxt(
    os.path.join(args.store_dir, 'u_pred.dat')).reshape(-1, 1)
u_true = np.loadtxt(
    os.path.join(args.store_dir, 'u_true.dat')).reshape(-1, 1)

# reshape
u_true_grid = u_true.reshape(n_spatial, n_spatial, n_time)
u_pred_grid = u_pred.reshape(n_spatial, n_spatial, n_time)
err_grid    = np.abs(u_true_grid - u_pred_grid)

x1     = np.linspace(-1.0, 1.0, n_spatial)
x2     = np.linspace(-1.0, 1.0, n_spatial)
t_vals = np.linspace(0.0, T, n_time)

# global error scale
vmax_err = np.max(err_grid)


# grid layout — max 3 columns
n_cols = min(3, n_time)
n_rows = math.ceil(n_time / n_cols)

fig, axes = plt.subplots(n_rows, n_cols,
                          figsize=(4.5*n_cols, 4.5*n_rows))

# flatten axes
axes_flat = np.array(axes).flatten()

# hide unused panels
for idx in range(n_time, len(axes_flat)):
    axes_flat[idx].set_visible(False)

im = None
for k in range(n_time):
    ax = axes_flat[k]

    im = ax.pcolormesh(x1, x2,
                   err_grid[:, :, k].T,
                   cmap='hot',
                   vmin=0.0, vmax=vmax_err,
                   shading='auto')


    ax.set_xlim([-1, 1])
    ax.set_ylim([-1, 1])
    ax.set_aspect('equal')
    ax.set_title(f'$t = {t_vals[k]:.2f}$', fontsize=12)
    ax.set_xlabel('$x_1$', fontsize=14)
    ax.set_ylabel('$x_2$', fontsize=14)
    ax.set_zlabel('Pointwise Error', fontsize=14, labelpad=15)



# colorbar — outside figure on the right
fig.subplots_adjust(right=0.88)
cbar_ax = fig.add_axes([0.91, 0.15, 0.02, 0.7])
cbar = fig.colorbar(im, cax=cbar_ax)
cbar.set_label('Pointwise Error',
               fontsize=11)

figures_dir = os.path.join(os.path.dirname(args.store_dir), 'Figures')
os.makedirs(figures_dir, exist_ok=True)
save_path = os.path.join(figures_dir,
    f'prob{args.probsetup}_pointwise_error.png')
plt.savefig(save_path, dpi=150, bbox_inches='tight')
plt.close()
print(f'Plot saved to {save_path}')
print(f'Max pointwise error: {vmax_err:.4e}')
for k in range(n_time):
    print(f't={t_vals[k]:.2f}: max error = {np.max(err_grid[:,:,k]):.4e}')