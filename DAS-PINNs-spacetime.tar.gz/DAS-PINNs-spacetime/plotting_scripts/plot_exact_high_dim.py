# File: plot_exact_high_dim.py
# Author: Anshima Singh, June 2026
# Description: Plots exact solution for high-dimensional problems
#              at four time levels (t = 0.00, 0.25, 0.50, 1.00).
#              Includes one figure with four columns (one per time level).



import numpy as np
import matplotlib.pyplot as plt
import os
import argparse
import itertools

##############################################################
# ARGUMENT PARSER
##############################################################
parser = argparse.ArgumentParser(
    description='Plot 2D exact solution solution slices for high-dimensional problems')
parser.add_argument("--probsetup", type=int, default=22,
               help='The problem setup: 22, A high-dimensional parabolic problem; '
                    '23, A high-dimensional hyperbolic problem. ')
parser.add_argument("--alpha", type=float, default=0.1,
               help='Problem-dependent coefficient: '
                    '22, Gaussian coefficient - default 10.0; '
                    '23, Gaussian coefficient - default 0.1. ')
parser.add_argument('--store_dir', type=str, default='./store_data',
                    help='Directory containing results')
parser.add_argument('--n_dim', type=int, default=9,
                    help='Total dimension including time (d+1). '
                         'e.g. 7 for d=6, 9 for d=8')
parser.add_argument('--n_grid', type=int, default=100,
                    help='Number of grid points per spatial dimension '
                         'for the 2D slice plot')
parser.add_argument('--n_time', type=int, default=4,
                    help='Number of time slices')
parser.add_argument('--T', type=float, default=1.0,
                    help='Final time')
parser.add_argument('--lam', type=float, default=5.0,
                    help='Rate parameter lambda in exact solution')
parser.add_argument('--ckpt_dir', type=str, default='./pdf_ckpt',
                    help='Ignored by this script; accepted for CLI compatibility')
parser.add_argument('--dim_pairs', type=str, default='all',
                    help='Which dimension pairs to plot. '
                         '"all" plots all unique pairs. '
                         'Or specify as "0,1 0,2 1,2" etc.')


args = parser.parse_args()

n_spatial = args.n_dim - 1
T         = args.T
lam       = args.lam
n_grid    = args.n_grid
n_time    = args.n_time

##############################################################
# FIGURES DIRECTORY
##############################################################
figures_dir = os.path.join(os.path.dirname(args.store_dir), 'Figures')
os.makedirs(figures_dir, exist_ok=True)

##############################################################
# EXACT SOLUTION
##############################################################
def exact_solution(X1, X2, t, dim_i, dim_j):
    if args.probsetup == 22:
        norm_sq = X1**2 + X2**2
        G       = np.exp(-10.0 * norm_sq)
        u       = G * (1.0 - np.exp(-lam * t))
        return u

    elif args.probsetup == 23:
        x_other = t
        n_other = n_spatial - 2
        norm_sq = (X1 - t)**2 + (X2 - t)**2 + \
                  n_other * (x_other - t)**2
        u       = np.exp(-(1.0 / args.alpha) * norm_sq)
        return u

##############################################################
# DETERMINE DIMENSION PAIRS
##############################################################
if args.dim_pairs == 'all':
    pairs = list(itertools.combinations(range(n_spatial), 2))
else:
    pairs = []
    for pair_str in args.dim_pairs.strip().split():
        i, j = pair_str.split(',')
        pairs.append((int(i), int(j)))

print(f'Spatial dimension d = {n_spatial}')
pairs_display = [(i+1, j+1) for i, j in pairs]
print(f'Plotting {len(pairs)} dimension pairs: {pairs_display}')

##############################################################
# TIME LEVELS
##############################################################
t_vals = [0.0, 0.25, 0.5, 1.0]

##############################################################
# SPATIAL GRID
##############################################################
if args.probsetup == 23:
    x_grid = np.linspace(-0.2, 1.2, n_grid)
else:
    x_grid = np.linspace(-1.0, 1.0, n_grid)

X1_2d, X2_2d = np.meshgrid(x_grid, x_grid, indexing='ij')

##############################################################
# LOOP OVER DIMENSION PAIRS
##############################################################
for (dim_i, dim_j) in pairs:

    print(f'\n=== Plotting x{dim_i+1} vs x{dim_j+1} ===')

    u_exact_all = np.zeros((n_grid, n_grid, n_time))

    for k, t_val in enumerate(t_vals):
        u_exact_all[:, :, k] = exact_solution(
            X1_2d, X2_2d, t_val, dim_i, dim_j)

    vmin_sol = 0.0
    vmax_sol = np.max(u_exact_all)

    fig, axes = plt.subplots(1, n_time, figsize=(4 * n_time, 4))

    for k, t_val in enumerate(t_vals):
        if args.probsetup in (23, 24):
            peak_x, peak_y = t_val, t_val
        else:
            peak_x, peak_y = 0.0, 0.0

        im = axes[k].contourf(
            x_grid, x_grid, u_exact_all[:, :, k],
            levels=50, cmap='hot',
            vmin=vmin_sol, vmax=vmax_sol)
        axes[k].set_title(f'$t = {t_val:.2f}$', fontsize=12)
        axes[k].set_xlabel(f'$x_{dim_i+1}$', fontsize=11)
        axes[k].plot(peak_x, peak_y, 'm*',
                     markersize=10, markeredgewidth=1, zorder=5)
        plt.colorbar(im, ax=axes[k])

    axes[0].set_ylabel(f'Exact solution\n$x_{dim_j+1}$', fontsize=12)

    plt.tight_layout()

    save_path = os.path.join(
        figures_dir,
        f'prob{args.probsetup}_exact_x{dim_i+1}_x{dim_j+1}.png')
    plt.savefig(save_path, dpi=150, bbox_inches='tight')
    plt.close()
    print(f'  Saved: {save_path}')

print('\n=== All exact solution plots saved ===')